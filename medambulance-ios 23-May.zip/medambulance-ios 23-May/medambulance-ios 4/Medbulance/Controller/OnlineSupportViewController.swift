//
//  OnlineSupportViewController.swift
//  Medbulance
//
//  Created by Apple on 12/03/21.
//

import UIKit

class OnlineSupportViewController: BaseViewControllerClass {
    
    @IBOutlet weak var sideBarNavigationView: SideMenuNavigationBar!
    var sideDrawerMenu = SideBarView()
    
    static var viewControllerId = "OnlineSupportViewController"
    static var storyBoard = StoryboardConstant.driver

    override func viewDidLoad() {
        super.viewDidLoad()
        appDelegate.window = UIWindow(frame: UIScreen.main.bounds)
        sideDrawerMenu = SideBarView(frame: appDelegate.window!.frame)
        sideDrawerMenu.logoutDelegate = self
        sideDrawerMenu.delegate = self
        sideDrawerMenu.isUser = false

        setUpSideMenuNavigation()

        
    }
    
    func setUpSideMenuNavigation(){
        sideBarNavigationView.lblTitle.text = "Online Support"
        sideBarNavigationView.delegate = self
    }
    
    func showNavigationDrawer() {
        if(sideDrawerMenu != nil && !sideDrawerMenu.isHidden)
        {
            sideDrawerMenu.removeFromSuperview()
        }
      
        sideDrawerMenu.isHidden = false
        UIView.animateKeyframes(withDuration: 0.25, delay: 0, options: [], animations: {
            self.sideDrawerMenu.tableContainerView.center.x += self.view.bounds.width
            
        }, completion: nil)
        self.sideDrawerMenu.delegate = self
        self.view.addSubview(sideDrawerMenu)
        //sideDrawerMenu.tableContainerView.layer.removeAllAnimations()
    }
    
}
extension OnlineSupportViewController:SideBarViewDelegate,SideMenuNavigationBarDelegate,SideBarViewLogoutDelegate{
    func logoutTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "WelcomeNavController")
        let vc = WelcomeViewController.instantiateFromStoryBoard()
        self.push(vc)
    }
    
    func menuBtnTapped() {
        showNavigationDrawer()
    }
    
    
    func profileTapped(viewController: String) {
        
    }
    
    func homeTapped(viewController: String) {
        let controller = DriverHomeViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func myProfileTapped(viewController: String) {
        let controller = DriverMyProfileViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func myTripsTapped(viewController: String) {
        let controller = MyTripsViewController.instantiateFromStoryBoard()
        self.push(controller)
        
    }
    
    func notificationsTapped(viewController: String) {
        let controller = NotificationsViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func onlineSupportTapped(viewController: String) {
        let controller = OnlineSupportViewController.instantiateFromStoryBoard()
        self.push(controller)
        
    }
    
    
}
