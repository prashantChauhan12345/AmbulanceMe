//
//  UserSignUpViewController.swift
//  Medbulance
//
//  Created by MacMini  on 05/03/21.
//

import UIKit

class UserSignUpViewController: BaseViewControllerClass {
    static var viewControllerId = "UserSignUpViewController"
    static var storyBoard = StoryboardConstant.user
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func action_btn_ok(_ sender: Any) {
        
        let controller = UserVerifyOTPViewController.instantiateFromStoryBoard()
        self.push(controller)
        
    }
    
}
