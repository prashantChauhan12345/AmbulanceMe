//
//  SignUpDriverPhoneViewController.swift
//  Medbulance
//
//  Created by Apple on 23/02/21.
//

import UIKit

class SignUpDriverPhoneViewController: BaseViewControllerClass {
    
    static var viewControllerId = "SignUpDriverPhoneViewController"
    static var storyBoard = StoryboardConstant.driver

    @IBOutlet weak var phoneContainerView: UIView!
    
    @IBOutlet weak var btnContinue: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setInitials()
    }
    
    func setInitials(){
        
        phoneContainerView.layer.borderWidth = 1
        phoneContainerView.layer.borderColor = UIColor.lightGray.cgColor
    }
    

    @IBAction func btnContinueAction(_ sender: Any) {
        let controller = VerifyOTPViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    

}
