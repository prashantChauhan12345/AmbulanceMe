//
//  UserServicesTableViewCell.swift
//  Medbulance
//
//  Created by MacMini  on 16/03/21.
//

import UIKit

class UserServicesTableViewCell: UITableViewCell {

    
    @IBOutlet weak var view_AmbualnceServices: UIView!
    @IBOutlet weak var lbl_servicesDetail: UILabel!
    
    @IBOutlet weak var lbl_redDot: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       
        lbl_redDot.cornerRadius = 5
        lbl_redDot.clipsToBounds = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
