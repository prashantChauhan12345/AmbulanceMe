//
//  AppDelegate.swift
//  Medbulance
//
//  Created by Apple on 23/02/21.
//

import UIKit
import IQKeyboardManagerSwift
import GoogleMaps
import GooglePlaces
import Stripe

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    let apiKey = "AIzaSyAE5XGuHrupnpdgRtGwG39Kf2wT4B_HBbc"
    let STRIPE_LIVE_KEY = ""
    let STRIPE_TEST_KEY = "pk_test_51IgNkASIHawDbefyTXBlx6jfQLDtA0CTaDEu1CJSRCDUyAAoqrIMUkAr3DUyPfHOWo1Q1tYqcS3AUJt7cxpBdGV7009IPb7pif"

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        AppHelper.getUserDetails()
        AppHelper.getDriverDetails()
        GMSServices.provideAPIKey(apiKey)
        GMSPlacesClient.provideAPIKey(apiKey)
        IQKeyboardManager.shared.enable = true
        StripeAPI.defaultPublishableKey = "pk_test_51IgNkASIHawDbefyTXBlx6jfQLDtA0CTaDEu1CJSRCDUyAAoqrIMUkAr3DUyPfHOWo1Q1tYqcS3AUJt7cxpBdGV7009IPb7pif"
        STPPaymentConfiguration.shared.publishableKey = STRIPE_TEST_KEY
    
        return true
    }
    //=====================================
    // MARK: UISceneSession Lifecycle
    //=====================================

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    
    func setLoginAsRootViewController(){
        let vc = LoginSigupViewController.instantiateFromStoryBoard()
        self.window?.rootViewController = vc
        self.window?.makeKeyAndVisible()
    }
    
    func setWelcomeAsRootViewController(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "WelcomeViewController")
        let navigationVC = UINavigationController(rootViewController: controller)
        navigationVC.navigationBar.isHidden = true
        APPDELEGATE.window?.rootViewController = navigationVC
      //  self.window?.makeKeyAndVisible()
        
    }
    
    
}
extension UIViewController{
    func redirectToMainNavRVC(currentVC: UIViewController){
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
        if #available(iOS 13.0, *){
            if let scene = UIApplication.shared.connectedScenes.first{
                guard let windowScene = (scene as? UIWindowScene) else { return }
                print(">>> windowScene: \(windowScene)")
                let window: UIWindow = UIWindow(frame: windowScene.coordinateSpace.bounds)
                window.windowScene = windowScene //Make sure to do this
                window.rootViewController = currentVC
                window.makeKeyAndVisible()
                appDelegate.window = window
            }
        } else {
            appDelegate.window?.rootViewController = currentVC
            appDelegate.window?.makeKeyAndVisible()
        }
    }
}
/*
extension UIViewController {
        var appDelegate: AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    var sceneDelegate: SceneDelegate? {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
            let delegate = windowScene.delegate as? SceneDelegate else { return nil }
         return delegate
    }
}

extension UIViewController {
    var window: UIWindow? {
        if #available(iOS 13, *) {
            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                let delegate = windowScene.delegate as? SceneDelegate, let window = delegate.window else { return nil }
                   return window
        }
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate, let window = delegate.window else { return nil }
        return window
    }
}
*/
