//
//  UserRidesTableViewCell.swift
//  Medbulance
//
//  Created by MacMini  on 08/03/21.
//

import UIKit

class UserRidesTableViewCell: UITableViewCell {
    
    @IBOutlet weak var viewcell_rides: UIView!
    @IBOutlet weak var lbl_DayDateTime: UILabel!
    @IBOutlet weak var lbl_Fare: UILabel!
    @IBOutlet weak var lbl_Start: UILabel!
    @IBOutlet weak var lbl_HospitalAddress: UILabel!
    @IBOutlet weak var lbl_Type: UILabel!
    @IBOutlet weak var lbl_BookingID: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
