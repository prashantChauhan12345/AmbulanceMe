//
//  AmbulanceModel.swift
//  Medbulance
//
//  Created by Apple on 22/03/21.
//

import UIKit
import SwiftyJSON

class AmbulanceModel: NSObject {
    
    var name = ""
    var distance = ""
    var lat = ""
    var ambulanceNo = ""
    var lng = ""
    var ambulanceTypeId = ""
    var ambulanceId = ""
    var driverId = ""
    var mobileNo = ""
    var ambulanceModeId = ""
    
    class func getAllAmbulanceListArray(ambulanceArray:[JSON]) -> Array<AmbulanceModel>{
        var ambulanceDataArray = Array<AmbulanceModel>()
        for elements in ambulanceArray{
            let dataDetails = AmbulanceModel.parseAmbulanceData(details: elements)
            ambulanceDataArray.append(dataDetails)
        }
        return ambulanceDataArray
    }
    
    class func parseAmbulanceData(details:JSON) -> AmbulanceModel{
        let ambulanceDetails = AmbulanceModel()
        ambulanceDetails.name = details["name"].string ?? ""
      
        ambulanceDetails.ambulanceNo = details["ambulanceNo"].string ?? ""
        ambulanceDetails.distance = "\(details["distance"].int ?? 0)"
        ambulanceDetails.ambulanceTypeId = "\(details["status"].int ?? 0)"
        ambulanceDetails.lat = "\(details["lat"].double ?? 0.0)"
       
        ambulanceDetails.lng = "\(details["lng"].double ?? 0.0)"
        ambulanceDetails.ambulanceId = "\(details["ambulanceId"].int ?? 0)"
        
        ambulanceDetails.driverId = details["driverId"].string ?? ""
        ambulanceDetails.mobileNo = details["mobileNo"].string ?? ""

        ambulanceDetails.ambulanceModeId = details["ambulanceModeId"].string ?? ""
        return ambulanceDetails
    }

}
