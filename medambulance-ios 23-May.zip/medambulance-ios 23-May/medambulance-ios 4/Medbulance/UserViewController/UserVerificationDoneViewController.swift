//
//  UserVerificationDoneViewController.swift
//  Medbulance
//
//  Created by MacMini  on 05/03/21.
//

import UIKit

class UserVerificationDoneViewController: BaseViewControllerClass {
    
    static var viewControllerId = "UserVerificationDoneViewController"
    static var storyBoard = StoryboardConstant.user

    @IBOutlet weak var view_done: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view_done.layer.shadowColor = UIColor.lightGray.cgColor
        view_done.layer.shadowOpacity = 1
        view_done.layer.shadowRadius = 10
        view_done.layer.shadowOffset = CGSize(width: 1, height: 1)
    }
    

    @IBAction func action_ok_btn(_ sender: Any) {
        
        let controller = GetLocationViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
}


