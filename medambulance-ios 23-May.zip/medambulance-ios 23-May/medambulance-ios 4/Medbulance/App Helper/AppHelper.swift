//
//  AppHelper.swift
//  Medbulance
//
//  Created by Apple on 15/03/21.
//

import UIKit
let APPDELEGATE = UIApplication.shared.delegate as! AppDelegate
typealias AlertCompletion = (_ action: UIAlertAction)->(Void)
class AppHelper: NSObject {
    
    class func convertDateToFormattedDateString(date: Date) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        //   dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.string(from: date)
    
        
    }
    
    class func resetUserDefaults() {
       
           let defaults = UserDefaults.standard
           let dictionary = defaults.dictionaryRepresentation()
           dictionary.keys.forEach { key in
              
                   defaults.removeObject(forKey: key)
           }
           
        UserDetails.sharedInstance.Id = ""
        UserDetails.sharedInstance.Name = ""
        UserDetails.sharedInstance.Phone = ""
        UserDetails.sharedInstance.profileImage = ""
        
        DriverDetails.sharedInstance.Id = ""
        DriverDetails.sharedInstance.Name = ""
        DriverDetails.sharedInstance.Phone = ""
        DriverDetails.sharedInstance.profileImage = ""
        DriverDetails.sharedInstance.Email = ""
           
           AppHelper.saveUserDetails()
           
       }
    
    
    class func getUserDetails(){
        
        UserDetails.sharedInstance.Id = UserDefaultOperations.getStringObject("Id")
        UserDetails.sharedInstance.Name = UserDefaultOperations.getStringObject("Name")
        UserDetails.sharedInstance.Phone = UserDefaultOperations.getStringObject("Phone")
        UserDetails.sharedInstance.profileImage = UserDefaultOperations.getStringObject("profileImage")
            
    }
    
    class func getDriverDetails(){
                
        DriverDetails.sharedInstance.Id = UserDefaultOperations.getStringObject("DriverId")
        DriverDetails.sharedInstance.Name = UserDefaultOperations.getStringObject("DriverName")
        DriverDetails.sharedInstance.Phone = UserDefaultOperations.getStringObject("DriverPhone")
        DriverDetails.sharedInstance.profileImage = UserDefaultOperations.getStringObject("DriverProfileImage")
        DriverDetails.sharedInstance.Email = UserDefaultOperations.getStringObject("Email")
    }
    
    class func saveUserDetails(){
        UserDefaultOperations.setStringObject("Id", UserDetails.sharedInstance.Id)
        UserDefaultOperations.setStringObject("Name", UserDetails.sharedInstance.Name)
        UserDefaultOperations.setStringObject("Phone", UserDetails.sharedInstance.Phone)
        UserDefaultOperations.setStringObject("profileImage", UserDetails.sharedInstance.profileImage)
        
    }
    
    class func saveDriverDetails(){

        UserDefaultOperations.setStringObject("DriverId", DriverDetails.sharedInstance.Id)
        UserDefaultOperations.setStringObject("DriverName", DriverDetails.sharedInstance.Name)
        UserDefaultOperations.setStringObject("DriverPhone", DriverDetails.sharedInstance.Phone)
        UserDefaultOperations.setStringObject("DriverProfileImage", DriverDetails.sharedInstance.profileImage)
        UserDefaultOperations.setStringObject("Email", DriverDetails.sharedInstance.Email)
        
    }
}
func showAlertWithCompletion(title: String?, message: String?, buttonTitle: String?, vc: UIViewController, completion:@escaping AlertCompletion) {
    let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
    let action = UIAlertAction(title: buttonTitle, style: .default, handler: completion)
    alert.addAction(action)
    alert.view.tintColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    vc.present(alert, animated: true, completion: nil)
}
