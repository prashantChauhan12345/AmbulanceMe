//
//  PersonalIdViewController.swift
//  Medbulance
//
//  Created by Apple on 25/02/21.
//

import UIKit
import DropDown
protocol PersonalIdViewControllerDelegate {
    func savePersonalTapped()
}

class PersonalIdViewController: BaseViewControllerClass,NavigationBarViewDelegate {
    
    
    let dropDownIT = DropDown()
    let idTypeCat = ["Aadhaar","Voter Id"]
    
    var image:UIImage?
    var selectedIndex = -1
    var deletedIndex = -1
    var licenseImageArray = [UIImage]()
    var delegate:PersonalIdViewControllerDelegate?
    
    
    private lazy var profileImageGallery: Gallery = Gallery(root: self) { [weak self] (img: UIImage) in
        guard let `self`                 = self else { return }
        self.image = img
        self.licenseImageArray.append(self.image!)
        self.itemList.reloadData()
    }
    
    @IBOutlet weak var txtFieldPersonalIdType: UITextField!
    @IBOutlet weak var txtFieldPersonalIdNumber: UITextField!
    
    static var viewControllerId = "PersonalIdViewController"
    static var storyBoard = StoryboardConstant.driver
    let array = ["Upload Front Image","Upload Back Image"]

    @IBOutlet weak var fieldContainerView: UIView!
    @IBOutlet weak var personalIdContainerView: UIView!
    @IBOutlet weak var navigationBar: NavigationBarView!
    @IBOutlet weak var itemList: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavigation()
        setInitials()
    }
    
    func setInitials(){
        fieldContainerView.layer.borderWidth = 1
        fieldContainerView.layer.borderColor = UIColor.lightGray.cgColor
        personalIdContainerView.layer.borderWidth = 1
        personalIdContainerView.layer.borderColor = UIColor.lightGray.cgColor
        
        itemList.delegate = self
        itemList.dataSource = self
        let nib = UINib(nibName: "DrivingLicenseTableViewCell", bundle: nil)
        itemList.register(nib, forCellReuseIdentifier: "DrivingLicenseTableViewCell")
        setupIdTypeDropDown()
    }
    
    func setupIdTypeDropDown() {
        dropDownIT.anchorView = txtFieldPersonalIdType
        // You can also use localizationKeysDataSource instead. Check the docs.
        dropDownIT.dataSource = idTypeCat
        dropDownIT.selectionAction = { [weak self] (index, item) in
            self?.txtFieldPersonalIdType.text = item
        }
    }
    
    
    func setUpNavigation(){
        navigationBar.delegate = self
        navigationBar.lblTitle.text = "Personal ID"
    }
    
    func backTapped() {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnSaveAction(_ sender: Any) {
        self.view.endEditing(true)
        if checkValidation(){
            let param = ["DriverId":DriverDetails.sharedInstance.Id,"personal_Id":txtFieldPersonalIdNumber.text!,"idType":txtFieldPersonalIdType.text!]
            uploadPersonalIdApi(params:param)
        }
       
    }
    
    func checkValidation() -> Bool {
        
        self.view.endEditing(true)
       
        if self.txtFieldPersonalIdType.text!.isEmpty {
            
            self.txtFieldPersonalIdType.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Personal Id type is required.")
            return false
        }
        
        if self.txtFieldPersonalIdNumber.text!.isEmpty {
            
            self.txtFieldPersonalIdNumber.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT,"Personal Id Number is required." )
            return false
        }
        
        if licenseImageArray.count < 2{
            self.showAlertWithMessage(ConstantStrings.ALERT, "Please select Personal Id Image")
            return false
        }
        
        return true
    }
    
    
    @IBAction func btnSelectIdTypeAction(_ sender: Any) {
        dropDownIT.show()
    }
    

}
extension PersonalIdViewController:UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = itemList.dequeueReusableCell(withIdentifier: "DrivingLicenseTableViewCell") as! DrivingLicenseTableViewCell
        cell.lblTitle.text = array[indexPath.row]
        cell.deleteBtn.tag = indexPath.row
        cell.delegate = self
        
        if selectedIndex == indexPath.row{
            if self.image != nil{
                cell.documentImageView.image = image
                cell.camImg.isHidden = true
            }
        }
        if deletedIndex == indexPath.row{
            cell.camImg.isHidden = false
            cell.documentImageView.image = nil
            deletedIndex = -1
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = itemList.cellForRow(at: indexPath) as? DrivingLicenseTableViewCell
        if cell?.documentImageView.image == nil{
            selectedIndex = indexPath.row
            profileImageGallery.show()
        }
    }
}

extension PersonalIdViewController:DrivingLicenseTableViewCellDelegate{
    
    func deleteTapped(index: Int) {
        deletedIndex = index
        itemList.reloadData()
        if index == 1 && self.licenseImageArray.count == 1{
            self.licenseImageArray.remove(at:0)
        }else{
            self.licenseImageArray.remove(at:index)
        }
    }
    
    
}
extension PersonalIdViewController{
    
   
    
    func uploadPersonalIdApi(params:[String:String]){
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
       // imageDataArray.removeAll()
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        var imageArray = Array<Data>()
        for imageD in self.licenseImageArray{
            let imageData = imageD.jpegData(compressionQuality: 0.5)
            imageArray.append(imageData!)
        }
       
       
     //   imageDataArray.append(imageData as! NSData)
        WebServiceHandler.performMultipartRequest(urlString: kPersonalDetails, fileName: "image", params: params, imageDataArray: imageArray ){(result,error) in
            if result != nil{
                let responseCode = result!["statusCode"]?.int
                if responseCode == 200
                {
                    if let response = result{
                        self.delegate?.savePersonalTapped()
                        self.navigationController?.popViewController(animated: true)
                        let message = response["message"]?.string
                      //  self.showAlertWithMessage(ConstantStrings.ALERT, message!)
                        if let customer = response["data"]?.dictionary{
                        }
                        // AppHelper.saveUserDetails()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        }
                        
                    }
                }
                else{
                    if let errorMsg = result!["message"]?.string{
                        self.showAlertWithMessage("ALERT", errorMsg)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}
