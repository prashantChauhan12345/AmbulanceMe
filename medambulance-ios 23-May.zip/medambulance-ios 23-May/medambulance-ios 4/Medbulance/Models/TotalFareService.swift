//
//  TotalFareService.swift
//  Medbulance
//
//  Created by MacMini  on 22/05/21.
//

import UIKit
import SwiftyJSON

class TotalFareService: NSObject {

    var __v = ""
    var createdAt = ""
    var name = ""
    var _id = ""
    var ambtype = ""
    var services = [String]()
    var updatedAt = ""
    var price = ""
  
  
  class func getTotalFareServiceArray(totalFareArray:[JSON]) -> Array<TotalFareService>{
      var totalFareDataArray = Array<TotalFareService>()
      for elements in totalFareArray{
          let dataDetails = TotalFareService.parseTotalFareData(details: elements)
        totalFareDataArray.append(dataDetails)
      }
      return totalFareDataArray
  }
  
  class func parseTotalFareData(details:JSON) -> TotalFareService{
      let totalFareDetails = TotalFareService()
    totalFareDetails.name = details["name"].string ?? ""
    
    totalFareDetails.__v = details["__v"].string ?? ""
    totalFareDetails.createdAt = "\(details["createdAt"].string ?? "")"
    totalFareDetails._id = "\(details["_id"].string ?? "")"
    totalFareDetails.ambtype = "\(details["ambtype"].string ?? "")"
     
    totalFareDetails.updatedAt = "\(details["updatedAt"].string ?? "")"
      
      if let servicesArray = details["services"].array{
          for i in servicesArray{
            totalFareDetails.services.append(i.string ?? "")
          }
      }
   
    totalFareDetails.price = "\(details["price"].int ?? 0)"
      
      return totalFareDetails
  }
    
}
