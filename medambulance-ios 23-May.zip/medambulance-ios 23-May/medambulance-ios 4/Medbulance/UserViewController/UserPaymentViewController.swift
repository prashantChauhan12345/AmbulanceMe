//
//  UserPaymentViewController.swift
//  Medbulance
//
//  Created by MacMini  on 12/03/21.
//

import UIKit
import Razorpay
import SwiftyJSON


class UserPaymentViewController: BaseViewControllerClass,RazorpayPaymentCompletionProtocol  {
    func onPaymentError(_ code: Int32, description str: String) {
        let alert = UIAlertController(title: "Failure", message: str, preferredStyle: .alert)
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancel)
        self.view.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    func onPaymentSuccess(_ payment_id: String) {
        let alert = UIAlertController(title: "Success", message: payment_id, preferredStyle: .alert)
        let cancel = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(cancel)
        self.view.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    
    
    var razorpay:RazorpayCheckout?
    
    static var viewControllerId = "UserPaymentViewController"
    static var storyBoard = StoryboardConstant.user
    
    var sideDrawerMenu = SideBarView()
    
    @IBOutlet weak var sideBarNavigationView: SideMenuNavigationBar!
    @IBOutlet weak var viewSavedCard: UIView!
    @IBOutlet weak var DebitcardCollectionView: UICollectionView!
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var imgView_Card: UIImageView!
    @IBOutlet weak var imgView_Cash: UIImageView!
    var driverId = ""

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        razorpay = RazorpayCheckout.initWithKey("",andDelegate: self)
        
        appDelegate.window = UIWindow(frame: UIScreen.main.bounds)
        sideDrawerMenu = SideBarView(frame: appDelegate.window!.frame)
        sideDrawerMenu.delegateUser = self
        sideDrawerMenu.logoutDelegate = self
        sideDrawerMenu.isUser = true
        setUpSideMenuNavigation()
        
        self.navigationController?.isNavigationBarHidden = true
        
        DebitcardCollectionView.delegate = self
        DebitcardCollectionView.dataSource = self
        
        viewSavedCard.isHidden = true
        self.heightConstraint.constant = 10
        //        imgView_Card.isHidden = true
        //        imgView_Cash.isHidden = true
        
        
        nib()
        
    }
    
    
    
    internal func showpaymentform()
    {
        let options: [String:Any] = [
            "amount": "100", // 100 rupee = 1 rupee
            "description": "How to use Razorpay Payment Gatway",
            "image": "https://www.supinehub.com/img/SupineHubLogo.gif",
            "name" : "Swift Hub Learning",
            "prefill": [
                "contact" : "0000000000",
                "email" : "demo@gmail.com"
            ],
            "theme": [
                "color" : "#fdc5e7"
            ]
        ]
        razorpay!.open(options)
    }
    
    
    @IBAction func action_debitCard(_ sender: Any) {
        
        //   let controller = UserAddCardViewController.instantiateFromStoryBoard()
        //     controller.delegate = self
        //     self.push(controller)
        showpaymentform()
        
        //  imgView_Card.image = UIImage(named: "clicked")
        //  imgView_Card.image = UIImage(named: "unclicked")
        
    }
    
    
    @IBAction func action_Cash(_ sender: Any) {
        
        let param = [
            "UserId" : UserDetails.sharedInstance.Id,
            "DriverId": self.driverId,
            "bookingId":"",
            "paymentType":"cash",
            "Amount": ""
        ]
        callPaymentAddApi(params: param)
    }
    
    func nib() {
        let nib = UINib(nibName: "UserDebitcardCollectionViewCell", bundle: nil)
        DebitcardCollectionView.register(nib, forCellWithReuseIdentifier: "UserDebitcardCollectionViewCell")
    }
    
    
    func setUpSideMenuNavigation(){
        sideBarNavigationView.lblTitle.text = "Payment"
        sideBarNavigationView.delegate = self
        sideBarNavigationView.btnSideMenu.setImage(UIImage(named: "blackarrowback"), for: .normal)
    }
    
    func showNavigationDrawer() {
        if(sideDrawerMenu != nil && !sideDrawerMenu.isHidden)
        {
            sideDrawerMenu.removeFromSuperview()
        }
        
        sideDrawerMenu.isHidden = false
        UIView.animateKeyframes(withDuration: 0.25, delay: 0, options: [], animations: {
            self.sideDrawerMenu.tableContainerView.center.x += self.view.bounds.width
            
        }, completion: nil)
        sideDrawerMenu.delegateUser = self
        self.view.addSubview(sideDrawerMenu)
        //sideDrawerMenu.tableContainerView.layer.removeAllAnimations()
    }
    
}

extension UserPaymentViewController: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = DebitcardCollectionView.dequeueReusableCell(withReuseIdentifier: "UserDebitcardCollectionViewCell", for: indexPath) as? UserDebitcardCollectionViewCell
        return cell!
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 280, height: 180)
    }
}
extension UserPaymentViewController:SideMenuNavigationBarDelegate,SideBarViewUserDelegate,UserAddCardViewControllerDelegate,SideBarViewLogoutDelegate{
    func logoutTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "WelcomeNavController")
        let vc = WelcomeViewController.instantiateFromStoryBoard()
        self.push(vc)
    }
    
    
    func refreshData() {
        viewSavedCard.isHidden = false
        self.heightConstraint.constant = 360
    }
    
    
    func profileTapped(viewController: String) {
        let controller = UserMyProfileViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func bookYourRideTapped(viewController: String) {
        let controller = HomeViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func yourRideTapped(viewController: String) {
        let controller = UserRidesViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func rateCardTapped(viewController: String) {
        let controller = UserRateCardViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func supportTapped(viewController: String) {
        let controller = UsersupportViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func aboutTapped(viewController: String) {
        let controller = UserAboutViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func paymentTapped(viewController: String) {
        let controller = UserPaymentViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func menuBtnTapped() {
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension UserPaymentViewController {
    func callPaymentAddApi(params:[String:String]){
        
        /*
         if !AppHelper.isInterNetConnectionAvailable(){
         showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
         return
         }
         */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPOSTRequest(withURL: kPaymentAdd , andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    if let data = result?["data"]?.dictionary{
                        if let paymentdetails = data["detailsPayment"]?.dictionary{
                            
                        }
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                        // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
    
}
