//
//  UserVerifyOTPViewController.swift
//  Medbulance
//
//  Created by MacMini  on 04/03/21.
//

import UIKit

class UserVerifyOTPViewController: BaseViewControllerClass {
    
    static var viewControllerId = "UserVerifyOTPViewController"
    static var storyBoard = StoryboardConstant.user
    
    @IBOutlet weak var lblNumber: UILabel!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl4: UILabel!
    
    @IBOutlet var txtFieldArray: [UITextField]!
    @IBOutlet weak var btnVerify: UIButton!
    
    
    
    
    var otpStr = ""
    var number = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setInitials()
    }
    
    func setInitials(){
        lblNumber.text = number
        let txtField = txtFieldArray[0]
        txtField.becomeFirstResponder()
        
        for txField in txtFieldArray{
            txField.delegate = self
        }
    }
    
    @IBAction func action_verify(_ sender: Any) {
        
        otpStr = ""
        for txtField in txtFieldArray {
            if txtField.text != ""{
                
                otpStr = otpStr + txtField.text!
            }
            else{
                // showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PLEASE_ENTER_OTP)
                return;
            }
        }
        let param = ["m_otp":otpStr]
        requestforOTPverify(otp: otpStr)
        
        
        //        let param = ["m_otp":txtFieldArray.text!]
        //        requestforOTPverify(param: param)
        
    }
    
    
    
}

extension UserVerifyOTPViewController {
    
    func requestforOTPverify(otp:String){
        let param = ["m_otp":otp]
        
        WebServiceHandler.performPOSTRequest(withURL: URLBase.baseURL2 + appEndPoints.VerifyOTP, andParameters: param) {(result,error) in
            
            if result != nil {
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                
                if statusCode == 200 {
                    print(result!)
                    let message = result!["message"]?.stringValue
                    let controller = GetLocationViewController.instantiateFromStoryBoard()
                    self.push(controller)
                    //self.showAlertWithMessage("ALERT",  message!)
                }else{
                    
                    let message = result!["message"]?.stringValue
                    self.showAlertWithMessage("ALERT",  message!)
                }
                
            }
            
        }
        
    }
}

// MARK:- Text Field Delegate
extension UserVerifyOTPViewController:UITextFieldDelegate{
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        
        if string.count != 0 {
            if string == " " {
                return false
            }
            
            let lenght = range.location
            if (string.count == 1) && (lenght == 0) {
                fillTheOtp(textField: textField, string: string)
            }
            else{
                if lenght < txtFieldArray.count{
                    txtFieldArray[lenght].text = string
                }
            }
        }
        
        
        if string == UIPasteboard.general.string{
            
        }
        
        return true
    }
    
    
    
    func textField(_ textField: UITextField, didDeleteBackwardAnd wasEmpty: Bool) {
        if wasEmpty {
            
            let index = textField.tag - 11
            if index >= 0{
                txtFieldArray[index].becomeFirstResponder()
            }
        }
    }
    
    func fillTheOtp(textField: UITextField, string: String)  {
        weak var weakSelf = self
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.001) {
            
            if textField == weakSelf!.txtFieldArray[0]{
                if string == ""{
                    
                }else{
                    if (weakSelf!.txtFieldArray[1].text?.isEmpty)!{
                        textField.text = string
                        weakSelf!.txtFieldArray[1].becomeFirstResponder()
                        //                        self.lbl1.isHidden = true
                    }
                    else{
                        weakSelf!.txtFieldArray[0].text = string
                        weakSelf!.txtFieldArray[0].resignFirstResponder()
                        //                        self.lbl1.isHidden = false
                        
                    }
                }
            }else if textField == weakSelf!.txtFieldArray[1]{
                if string == ""{
                    weakSelf!.txtFieldArray[0].becomeFirstResponder()
                    
                }else{
                    if (weakSelf!.txtFieldArray[2].text?.isEmpty)!{
                        textField.text = string
                        weakSelf!.txtFieldArray[2].becomeFirstResponder()
                        //                        self.lbl2.isHidden = true
                    }
                    else{
                        weakSelf!.txtFieldArray[1].text = string
                        weakSelf!.txtFieldArray[1].resignFirstResponder()
                        //                        self.lbl2.isHidden = false
                        
                    }
                }
            }else if textField == weakSelf!.txtFieldArray[2]{
                if string == ""{
                    weakSelf!.txtFieldArray[1].becomeFirstResponder()
                    
                }else{
                    if (weakSelf!.txtFieldArray[3].text?.isEmpty)!{
                        textField.text = string
                        weakSelf!.txtFieldArray[3].becomeFirstResponder()
                        //                        self.lbl3.isHidden = true
                    }
                    else{
                        weakSelf!.txtFieldArray[2].text = string
                        weakSelf!.txtFieldArray[2].resignFirstResponder()
                        //                        self.lbl3.isHidden = false
                        
                    }
                }
                
            }else if textField == weakSelf!.txtFieldArray[3]{
                if string == ""{
                    weakSelf!.txtFieldArray[2].becomeFirstResponder()
                    //                    self.lbl4.isHidden = false
                    
                }else{
                    textField.text = string
                    textField.resignFirstResponder()
                    //                    self.lbl4.isHidden = true\
                }
                
            }
        }
    }
}
