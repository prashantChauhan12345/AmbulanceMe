//
//  PaymentUpdateStatusModel.swift
//  Medbulance
//
//  Created by MacMini  on 14/05/21.
//

import UIKit
import SwiftyJSON

class PaymentUpdateStatusModel: NSObject {

    var status = ""
    var _id = ""
    var Amount = ""
    var bookingId = ""
    var createdAt = ""
    var updatedAt = ""
    var paymentType = ""
    
    
    class func getPaymentUpdateStatusArray(userPaymentUpdataStatusArray:[JSON]) -> Array<PaymentUpdateStatusModel>{
        var userListDataArray = Array<PaymentUpdateStatusModel>()
        for elements in userPaymentUpdataStatusArray{
            let dataDetails = PaymentUpdateStatusModel.parseUserRideData(details: elements)
            userListDataArray.append(dataDetails)
        }
        return userListDataArray
    }
    
    
    class func parseUserRideData(details:JSON) -> PaymentUpdateStatusModel{
        let PaymentStatusUpdateDetails = PaymentUpdateStatusModel()
        PaymentStatusUpdateDetails.createdAt = details["createdAt"].string ?? ""
        PaymentStatusUpdateDetails._id = details["_id"].string ?? ""
        PaymentStatusUpdateDetails.status = details["status"].string ?? ""
        PaymentStatusUpdateDetails.paymentType = details["paymentType"].string ?? ""
        PaymentStatusUpdateDetails.Amount = details["Amount"].string ?? ""

        PaymentStatusUpdateDetails.bookingId = details["bookingId"].string ?? ""
        PaymentStatusUpdateDetails.updatedAt = details["updatedAt"].string ?? ""

        return PaymentStatusUpdateDetails
    }
    
}
