//
//  DriverMyProfileViewController.swift
//  Medbulance
//
//  Created by Apple on 17/03/21.
//

import UIKit

class DriverMyProfileViewController: BaseViewControllerClass {
    
    @IBOutlet weak var sideBarNavigationView: SideMenuNavigationBar!
    var sideDrawerMenu = SideBarView()

    static var viewControllerId = "DriverMyProfileViewController"
    static var storyBoard = StoryboardConstant.driver

    
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var txtFieldName: UITextField!
    
    @IBOutlet weak var txtFieldEmail: UITextField!
    @IBOutlet weak var txtFieldNumber: UITextField!
    
    var isEditTapped = false

    @IBOutlet weak var view_edit: UIView!
    @IBOutlet weak var view_save: UIView!
    @IBOutlet weak var img_pencilcircle: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtFieldName.text = DriverDetails.sharedInstance.Name
        txtFieldEmail.text = DriverDetails.sharedInstance.Email
        txtFieldNumber.text = DriverDetails.sharedInstance.Phone
        appDelegate.window = UIWindow(frame: UIScreen.main.bounds)
        sideDrawerMenu = SideBarView(frame: appDelegate.window!.frame)
        sideDrawerMenu.delegate = self
        sideDrawerMenu.logoutDelegate = self
        sideDrawerMenu.isUser = false
        
        txtFieldName.isEnabled = false
        txtFieldEmail.isEnabled = false
        
        self.view_edit.isHidden = false
        self.view_save.isHidden = true
        setUpSideMenuNavigation()
        callGetProfileDataApi()
    }
    
    
    func setUpSideMenuNavigation(){
        sideBarNavigationView.lblTitle.text = "My Profile"
        sideBarNavigationView.delegate = self
    }
    
    func showNavigationDrawer() {
        
        if(sideDrawerMenu != nil && !sideDrawerMenu.isHidden)
        {
            sideDrawerMenu.removeFromSuperview()
        }
      
        sideDrawerMenu.isHidden = false
        UIView.animateKeyframes(withDuration: 0.25, delay: 0, options: [], animations: {
            self.sideDrawerMenu.tableContainerView.center.x += self.view.bounds.width
        }, completion: nil)
        self.sideDrawerMenu.delegate = self
        self.view.addSubview(sideDrawerMenu)
        //sideDrawerMenu.tableContainerView.layer.removeAllAnimations()
    }
    
    @IBAction func action_image(_ sender: Any) {
        
    }
    
    @IBAction func action_Edit(_ sender: Any) {
        
        isEditTapped = true
        self.view_edit.isHidden = true
        txtFieldName.isEnabled = true
        txtFieldEmail.isEnabled = true
        self.view_save.isHidden = false

    }
    
    
    @IBAction func btnSaveAction(_ sender: Any) {
        
        isEditTapped = false
        view_save.isHidden = true
        txtFieldName.isEnabled = false
        txtFieldEmail.isEnabled = false
        view_edit.isHidden = false
        
        let params = ["name":"\(txtFieldName.text!)" , "email":"\(txtFieldEmail.text!)"]
        callUpdateProfile(params:params)
        
    }
    

}

extension DriverMyProfileViewController:SideBarViewDelegate,SideMenuNavigationBarDelegate,SideBarViewLogoutDelegate{
    
    func logoutTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "WelcomeNavController")
        let vc = WelcomeViewController.instantiateFromStoryBoard()
        self.push(vc)        
    }
    
    func menuBtnTapped() {
        showNavigationDrawer()
    }
    
    
    func profileTapped(viewController: String) {
        
    }
    
    func homeTapped(viewController: String) {
        let controller = DriverHomeViewController.instantiateFromStoryBoard()
        self.push(controller)
        
    }
    
    func myProfileTapped(viewController: String) {
        
        let controller = DriverMyProfileViewController.instantiateFromStoryBoard()
        self.push(controller)
        
    }
    
    func myTripsTapped(viewController: String) {
        let controller = MyTripsViewController.instantiateFromStoryBoard()
        self.push(controller)
        
    }
    
    func notificationsTapped(viewController: String) {
        let controller = NotificationsViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func onlineSupportTapped(viewController: String) {
        let controller = OnlineSupportViewController.instantiateFromStoryBoard()
        self.push(controller)
        
    }
    
}
extension DriverMyProfileViewController{
    
    func callGetProfileDataApi(){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performGETRequest(withURL: kGetDriverProfile + DriverDetails.sharedInstance.Id) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    if let myData = result?["data"]?.dictionary{
                        if let data = myData["driverdata"]?.dictionary{
                            self.txtFieldName.text! = data["drivername"]?.stringValue ?? ""
                            self.txtFieldNumber.text! = data["phone"]?.stringValue ?? ""
                            self.txtFieldEmail.text! = data["email"]?.stringValue ?? ""
                        }
                        DriverDetails.sharedInstance.Name = self.txtFieldName.text!
                        DriverDetails.sharedInstance.Phone = self.txtFieldNumber.text!
                        DriverDetails.sharedInstance.Email = self.txtFieldEmail.text!
                        
                        AppHelper.saveDriverDetails()
                        
                       // self.showAlertWithMessage(ConstantStrings.ALERT, "Your OTP is \(otp!)")
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                       // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
    
    func callUpdateProfile(params:[String:String]){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPUTRequest(withURL: kUpdateDriverProfile + DriverDetails.sharedInstance.Id, andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    
                    DriverDetails.sharedInstance.Name = self.txtFieldName.text!
                    DriverDetails.sharedInstance.Phone = self.txtFieldNumber.text!
                    DriverDetails.sharedInstance.Email = self.txtFieldEmail.text!
                    
                    AppHelper.saveDriverDetails()
                 
                    if let data = result?["data"]?.dictionary{
                        
                   
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                       // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}
