//
//  NavigationBarView.swift
//  Medbulance
//
//  Created by Apple on 25/02/21.
//

import UIKit
protocol NavigationBarViewDelegate {
    func backTapped()
}

class NavigationBarView: UIView {

    @IBOutlet var containerView: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    
    var delegate:NavigationBarViewDelegate?
    
    override init(frame:CGRect){
        super.init(frame: frame)
        commitInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commitInit()
    }
    
    func commitInit(){
        Bundle.main.loadNibNamed("NavigationBarView", owner: self, options: nil)
        addSubview(containerView)
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.delegate?.backTapped()
    }
    
}
