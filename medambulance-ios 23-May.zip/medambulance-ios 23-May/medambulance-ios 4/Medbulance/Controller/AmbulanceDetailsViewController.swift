//
//  AmbulanceDetailsViewController.swift
//  Medbulance
//
//  Created by Apple on 26/02/21.
//

import UIKit
import DropDown

class AmbulanceDetailsViewController: BaseViewControllerClass,NavigationBarViewDelegate{
  
    var isManufacturedDate = false
    
    let dropDownAC = DropDown()
    let dropDownAT = DropDown()
    let dropDownAM = DropDown()
    let dropDownFT = DropDown()
    
    let ambulanceType = ["Government","Semi-Government", "Private"]
    let fuelType = ["Petrol","Diesel","CNG"]
    let ambulanceModel = ["2021","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2007"]
    let ambulanceCategory = ["ALS","BLS","DBT","PVT"]
    
    @IBOutlet weak var txtFieldAmbulanceCategory: UITextField!
    @IBOutlet weak var txtFieldAmbulanceType: UITextField!
    @IBOutlet weak var txtFieldAmbulanceModel: UITextField!
    @IBOutlet weak var txtFieldRegistrationNo: UITextField!
    @IBOutlet weak var txtFieldFuelType: UITextField!
    @IBOutlet weak var camImg: UIImageView!
    @IBOutlet weak var documentImageView: UIImageView!
    @IBOutlet weak var txtFieldManufacturedDate: UITextField!
    @IBOutlet weak var txtFieldRegistrationDate: UITextField!
    
    @IBOutlet weak var dateContainerView: UIView!
    @IBOutlet weak var datePickerView: UIDatePicker!
    
    var image:UIImage?
    private lazy var profileImageGallery: Gallery = Gallery(root: self) { [weak self] (img: UIImage) in
        guard let `self`                 = self else { return }
        self.image = img
        self.documentImageView.image = img
        self.camImg.isHidden = true
    }
    
    static var viewControllerId = "AmbulanceDetailsViewController"
    static var storyBoard = StoryboardConstant.driver
    
    @IBOutlet weak var navigationBar: NavigationBarView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavigation()
        setupAmbulanceACDown()
        setupAmbulanceATDown()
        setupAMDown()
        setupFTDown()
        setInitials()
        
    }
    
    
    func setInitials(){
        dateContainerView.isHidden = true
    }
    
    
    func setUpNavigation(){
        navigationBar.delegate = self
        navigationBar.lblTitle.text = "Ambulance Details"
    }
    
    func setupAmbulanceATDown() {
        dropDownAT.anchorView = txtFieldAmbulanceType
        // You can also use localizationKeysDataSource instead. Check the docs.
        dropDownAT.dataSource = ambulanceType
        dropDownAT.selectionAction = { [weak self] (index, item) in
            self?.txtFieldAmbulanceType.text = item
        }
    }
    
    func setupAmbulanceACDown() {
        dropDownAC.anchorView = txtFieldAmbulanceCategory
        // You can also use localizationKeysDataSource instead. Check the docs.
        dropDownAC.dataSource = ambulanceCategory
        dropDownAC.selectionAction = { [weak self] (index, item) in
            self?.txtFieldAmbulanceCategory.text = item
        }
    }
    
    func setupAMDown() {
        dropDownAM.anchorView = txtFieldAmbulanceModel
        // You can also use localizationKeysDataSource instead. Check the docs.
        dropDownAM.dataSource = ambulanceModel
        dropDownAM.selectionAction = { [weak self] (index, item) in
            self?.txtFieldAmbulanceModel.text = item
        }
    }
    
    func setupFTDown() {
        dropDownFT.anchorView = txtFieldFuelType
        // You can also use localizationKeysDataSource instead. Check the docs.
        dropDownFT.dataSource = fuelType
        dropDownFT.selectionAction = { [weak self] (index, item) in
            self?.txtFieldFuelType.text = item
        }
    }
    
    @IBAction func btnSaveAction(_ sender: Any) {
        //
       // let controller = DocumentSubmittedViewController.instantiateFromStoryBoard()
        //  self.push(controller)
        self.view.endEditing(true)
        
        if checkValidation(){
            let param = ["DriverId":DriverDetails.sharedInstance.Id,"AmbulanceCategory":txtFieldAmbulanceCategory.text!,"AmbulanceType":txtFieldAmbulanceType.text!,"AmbulanceModel":txtFieldAmbulanceModel.text!,"RegistrationNumber":txtFieldRegistrationNo.text!,"FuelType":txtFieldFuelType.text!,"ManufacturedDate":txtFieldManufacturedDate.text!,"RegistrationDate":txtFieldRegistrationDate.text!]
            self.uploadAmbulanceApi(params: param)
        }
        
    }
    
    
    func checkValidation() -> Bool {
        
        self.view.endEditing(true)
        if self.txtFieldAmbulanceCategory.text!.isEmpty {
            
            self.txtFieldAmbulanceCategory.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Ambulance Category is Required")
            return false
        }
        
        if self.txtFieldAmbulanceType.text!.isEmpty {
            
            self.txtFieldAmbulanceType.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Ambulance Type is Required")
            return false
        }
        
        
        if self.txtFieldAmbulanceModel.text!.isEmpty {
            
            self.txtFieldAmbulanceModel.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Ambulance Model is Required")
            return false
        }
        
        
        
        
        if self.txtFieldRegistrationNo.text!.isEmpty {
            
            self.txtFieldRegistrationNo.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Registration No is Required")
            return false
        }
        
        
        if self.txtFieldFuelType.text!.isEmpty {
            
            self.txtFieldFuelType.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Fuel Type is Required")
            return false
        }
        
        if self.txtFieldManufacturedDate.text!.isEmpty {
            
            self.txtFieldManufacturedDate.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Manufactured Date is Required")
            return false
        }
        
        if self.txtFieldRegistrationDate.text!.isEmpty {
            
            self.txtFieldRegistrationDate.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Registration Date is Required")
            return false
        }
        
        
        return true
    }
    
    
    func backTapped() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnUploadAmbulanceImage(_ sender: UIButton) {
        if self.documentImageView.image == nil{
            profileImageGallery.show()
        }
    }
    
    @IBAction func btnACAction(_ sender: Any) {
        dropDownAC.show()
    }
    
    @IBAction func btnDeleteAction(_ sender: Any) {
        self.camImg.isHidden = false
        self.documentImageView.image = nil
    }
    @IBAction func btnATAction(_ sender: Any) {
        dropDownAT.show()
    }
    
    @IBAction func btnManufacturedDateAction(_ sender: Any) {
        self.view.endEditing(true)
        dateContainerView.isHidden = false
        isManufacturedDate = true
        
        
    }
    @IBAction func btnRegistrationDateAction(_ sender: Any) {
        self.view.endEditing(true)
        dateContainerView.isHidden = false
        isManufacturedDate = false
        
    }
    
    
    @IBAction func btnAMAction(_ sender: Any) {
        dropDownAM.show()
    }
    
    
    @IBAction func btnFTAction(_ sender: Any) {
        dropDownFT.show()
    }
    
    @IBAction func btnDonePickDateAction(_ sender: Any) {
        
        if isManufacturedDate {
            txtFieldManufacturedDate.text = "\(AppHelper.convertDateToFormattedDateString(date: datePickerView.date))"
        }else{
            txtFieldRegistrationDate.text = "\(AppHelper.convertDateToFormattedDateString(date: datePickerView.date))"
        }
        dateContainerView.isHidden = true
    }
    
    
}
extension AmbulanceDetailsViewController{
    
    func uploadAmbulanceApi(params:[String:String]){
        /*
         if !AppHelper.isInterNetConnectionAvailable(){
         showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
         return
         }
         */
        // imageDataArray.removeAll()
        
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        var imageData:Data?
        if image != nil{
            imageData = self.image!.jpegData(compressionQuality: 0.5)
            if imageData == nil{
                return;
            }
        }else{
            return
        }
        
        //   imageDataArray.append(imageData as! NSData)
        WebServiceHandler.performMultipartRequest(urlString: kAmbulanceDetails, fileName: "image", params: params, imageDataArray: [imageData!] ){(result,error) in
            if result != nil{
                let responseCode = result!["statusCode"]?.int
                if responseCode == 200
                {
                    
                    let controller = DocumentSubmittedViewController.instantiateFromStoryBoard()
                    self.push(controller)
                    if let response = result{
                        
                        let message = response["message"]?.string
                        // self.showAlertWithMessage(ConstantStrings.ALERT, message!)
                        if let customer = response["data"]?.dictionary{
                        }
                        // AppHelper.saveUserDetails()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        }
                        
                    }
                }
                else{
                    if let errorMsg = result!["message"]?.string{
                        self.showAlertWithMessage("ALERT", errorMsg)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}
