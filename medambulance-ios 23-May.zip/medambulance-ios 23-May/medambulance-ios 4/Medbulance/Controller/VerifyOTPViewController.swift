//
//  VerifyOTPViewController.swift
//  Medbulance
//
//  Created by Apple on 25/02/21.
//

import UIKit

class VerifyOTPViewController: BaseViewControllerClass {
    
    static var viewControllerId = "VerifyOTPViewController"
    static var storyBoard = StoryboardConstant.driver
    var otpStr = ""
    
    @IBOutlet weak var lblNumber: UILabel!
    var isRegister = true
    var phone = ""
    
    var number = ""
 
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl4: UILabel!
    
    @IBOutlet var txtFieldsArray: [UITextField]!
    @IBOutlet weak var btnVerify: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setInitials()
    }
    
    func setInitials(){
        lblNumber.text = number
        let txtField = txtFieldsArray[0]
        txtField.becomeFirstResponder()
        
        for txField in txtFieldsArray{
            txField.delegate = self
        }
    }
    
    @IBAction func btnVerifyAction(_ sender: Any) {
        
        otpStr = ""
        
        for txtField in txtFieldsArray {
            if txtField.text != ""{
                otpStr = otpStr + txtField.text!
            }
            else{
                showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PLEASE_ENTER_OTP)
                return;
            }
        }
       // let controller = VerifiedViewController.instantiateFromStoryBoard()
       // self.push(controller)
        callVerifyOTPApi(OTP: otpStr)
    }
    
}
// MARK:- Text Field Delegate
extension VerifyOTPViewController:UITextFieldDelegate{
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        
        if string.count != 0 {
            if string == " " {
                return false
            }

            let lenght = range.location
            if (string.count == 1) && (lenght == 0) {
                fillTheOtp(textField: textField, string: string)
            }
            else{
                if lenght < txtFieldsArray.count{
                   txtFieldsArray[lenght].text = string
                }
            }
        }
        if string == UIPasteboard.general.string{
            print("Print")
        }

        return true
    }
    
    

    func textField(_ textField: UITextField, didDeleteBackwardAnd wasEmpty: Bool) {
        if wasEmpty {

            let index = textField.tag - 11
            if index >= 0{
                txtFieldsArray[index].becomeFirstResponder()
            }
        }
    }
    
    func fillTheOtp(textField: UITextField, string: String)  {
        weak var weakSelf = self
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.001) {
            
            if textField == weakSelf!.txtFieldsArray[0]{
                if string == ""{
                    
                }else{
                    if (weakSelf!.txtFieldsArray[1].text?.isEmpty)!{
                        textField.text = string
                        weakSelf!.txtFieldsArray[1].becomeFirstResponder()
                        self.lbl1.isHidden = true
                    }
                    else{
                        weakSelf!.txtFieldsArray[0].text = string
                        weakSelf!.txtFieldsArray[0].resignFirstResponder()
                        self.lbl1.isHidden = false
                        
                    }
                }
            }else if textField == weakSelf!.txtFieldsArray[1]{
                if string == ""{
                    weakSelf!.txtFieldsArray[0].becomeFirstResponder()
                    
                }else{
                    if (weakSelf!.txtFieldsArray[2].text?.isEmpty)!{
                        textField.text = string
                        weakSelf!.txtFieldsArray[2].becomeFirstResponder()
                        self.lbl2.isHidden = true
                    }
                    else{
                        weakSelf!.txtFieldsArray[1].text = string
                        weakSelf!.txtFieldsArray[1].resignFirstResponder()
                        self.lbl2.isHidden = false
                        
                    }
                }
            }else if textField == weakSelf!.txtFieldsArray[2]{
                if string == ""{
                    weakSelf!.txtFieldsArray[1].becomeFirstResponder()
                    
                }else{
                    if (weakSelf!.txtFieldsArray[3].text?.isEmpty)!{
                        textField.text = string
                        weakSelf!.txtFieldsArray[3].becomeFirstResponder()
                        self.lbl3.isHidden = true
                    }
                    else{
                        weakSelf!.txtFieldsArray[2].text = string
                        weakSelf!.txtFieldsArray[2].resignFirstResponder()
                        self.lbl3.isHidden = false
                        
                    }
                }
                
            }else if textField == weakSelf!.txtFieldsArray[3]{
                if string == ""{
                    weakSelf!.txtFieldsArray[2].becomeFirstResponder()
                    self.lbl4.isHidden = false
                    
                }else{
                    textField.text = string
                    textField.resignFirstResponder()
                    self.lbl4.isHidden = true
                    
                }
                
            }
        }
    }
}
extension VerifyOTPViewController{
    
    func callVerifyOTPApi(OTP:String){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        
        var params = ["":""]
      
        var url = ""
            
        if isRegister {
            params = ["DriverId":DriverDetails.sharedInstance.Id,"m_otp":OTP]
            ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
            url = kVerifyOtpURL
        }else{
            
            params = ["m_otp":"\(OTP)"]
            url = kVerifyOtpURL
        }
        
        WebServiceHandler.performPOSTRequest(withURL: url, andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    if self.isRegister{
                        let controller = VerifiedViewController.instantiateFromStoryBoard()
                        self.push(controller)
                    }else{
                        let controller = ChangePasswordDriverViewController.instantiateFromStoryBoard()
                        controller.phone = self.phone
                        self.push(controller)
                    }
                    
                    
                    if let data = result?["data"]?.dictionary{
                        if let message = data["message"]?.stringValue{
                            self.showAlertWithMessage(ConstantStrings.ALERT, message)
                        }
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                       // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}
