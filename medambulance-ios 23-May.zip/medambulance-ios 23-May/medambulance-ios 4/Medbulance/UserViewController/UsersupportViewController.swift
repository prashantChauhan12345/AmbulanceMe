//
//  UsersupportViewController.swift
//  Medbulance
//
//  Created by MacMini  on 09/03/21.
//

import UIKit

class UsersupportViewController: BaseViewControllerClass {
    
    static var viewControllerId = "UsersupportViewController"
    static var storyBoard = StoryboardConstant.user
    
    var userRideList = [UserRideModel]()

    
    var sideDrawerMenu = SideBarView()
    @IBOutlet weak var sideBarNavigationView: SideMenuNavigationBar!

    @IBOutlet weak var tblview_support: UITableView!
    @IBOutlet weak var view_pickbooking: UIView!
 
    @IBOutlet weak var view_feedback: UIView!
    @IBOutlet weak var txt_feedback: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        appDelegate.window = UIWindow(frame: UIScreen.main.bounds)
        sideDrawerMenu = SideBarView(frame: appDelegate.window!.frame)
        
        self.txt_feedback.borderWidth = 1
        self.txt_feedback.borderColor = UIColor.black
        
        sideDrawerMenu.delegateUser = self
        sideDrawerMenu.logoutDelegate = self
        sideDrawerMenu.isUser = true
        setUpSideMenuNavigation()
        view_pickbooking.addBottomShadow()
        
        tblview_support.delegate = self
        tblview_support.dataSource = self
        
        let nib = UINib(nibName: "UserRidesTableViewCell", bundle: nil)
        tblview_support.register(nib, forCellReuseIdentifier: "UserRidesTableViewCell")
        
         getUserLastRideApi()

    }
    @IBOutlet weak var btn_OK: UIButton!
    

    func setUpSideMenuNavigation(){
        sideBarNavigationView.lblTitle.text = "Support"
        sideBarNavigationView.delegate = self
    }
    
    func getLocaleDateString( strDate: String) -> String {
        
        if strDate == "" {
            return ""
        }
        
        let dateFromatter = DateFormatter()
        dateFromatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        let date = dateFromatter.date(from:strDate)
        dateFromatter.timeZone = TimeZone(abbreviation:"UTC")
        dateFromatter.locale = Locale.init(identifier:"en_US_POSIX")
        
        let serverDate = dateFromatter.date(from: strDate)
        
        let date_Fromatter = DateFormatter()
        date_Fromatter.dateFormat =  "dd MMM yyyy  hh:mm a"  // "dd-MM-yyyy hh:mm a" //
        date_Fromatter.timeZone = NSTimeZone.local
        date_Fromatter.locale = Locale.init(identifier:"en_US_POSIX")
        
        if serverDate == nil {
            return ""
        }
        
        let localString = date_Fromatter.string(from: serverDate!)
        return localString
    }

    
    @IBAction func btn_feebackDone(_ sender: Any) {
        if checkValidation(){
            let params = ["feedback": self.txt_feedback.text]
        callFeedbackRequest(params: params)
            
        }
    }
    func checkValidation() -> Bool{
        if self.txt_feedback.text!.isEmpty {
            
            self.txt_feedback.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.FEEDBACK_FIELD_IS_EMPTY)

            return false
        } 
        
        return true
    }
    
    
    func showNavigationDrawer() {
        if(sideDrawerMenu != nil && !sideDrawerMenu.isHidden)
        {
            sideDrawerMenu.removeFromSuperview()
        }
      
        sideDrawerMenu.isHidden = false
        UIView.animateKeyframes(withDuration: 0.25, delay: 0, options: [], animations: {
            self.sideDrawerMenu.tableContainerView.center.x += self.view.bounds.width
            
        }, completion: nil)
        sideDrawerMenu.delegateUser = self
        self.view.addSubview(sideDrawerMenu)
        //sideDrawerMenu.tableContainerView.layer.removeAllAnimations()
    }

}

extension UsersupportViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return userRideList.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tblview_support.dequeueReusableCell(withIdentifier: "UserRidesTableViewCell") as? UserRidesTableViewCell
   
        cell?.lbl_Start.text = userRideList[indexPath.row].sorcaddress
        cell?.lbl_HospitalAddress.text = userRideList[indexPath.row].desaddress
        cell?.lbl_Fare.text = userRideList[indexPath.row].totalprice
        cell?.lbl_DayDateTime.text = self.getLocaleDateString(strDate: userRideList[indexPath.row].dateUpdate) 
        cell?.lbl_BookingID.text = userRideList[indexPath.row]._id
             
        return cell!
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 146
    }
    
    
    func getUserLastRideApi(){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performGETRequest(withURL: kUserLastRide + UserDetails.sharedInstance.Id) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    if let data = result?["data"]?.array{
                        
                        self.userRideList = UserRideModel.getUserRideListArray(userRideArray: data)
                        self.tblview_support.reloadData()
                        print(data)

                    }
                }
                else{
                    if let message = result!["message"]?.string{
                       // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
    func callFeedbackRequest(params:[String:Any]){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPUTRequest(withURL: kUserFeedback + UserDetails.sharedInstance.Id, andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
  
                    AppHelper.saveDriverDetails()
                 
                    if let data = result?["feedback"]?.dictionary{
                        self.txt_feedback.text = data["feedback"]?.stringValue ?? ""
                        let message = result?["message"]?.stringValue ?? ""
                        self.showAlertWithMessage("ALERT", message)
                        self.txt_feedback.text = ""
                    }
                }
                else{
                    if let message = result!["message"]?.string{
//                        AppHelper.showAlertView(message: "message")
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}


extension UsersupportViewController:SideMenuNavigationBarDelegate,SideBarViewUserDelegate,SideBarViewLogoutDelegate{
    func logoutTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "WelcomeNavController")
        let vc = WelcomeViewController.instantiateFromStoryBoard()
        self.push(vc)
    }
    
    
    func profileTapped(viewController: String) {
        let controller = UserMyProfileViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func bookYourRideTapped(viewController: String) {
        let controller = HomeViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func yourRideTapped(viewController: String) {
        let controller = UserRidesViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func rateCardTapped(viewController: String) {
        let controller = UserRateCardViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func supportTapped(viewController: String) {
        let controller = UsersupportViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func aboutTapped(viewController: String) {
        let controller = UserAboutViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func paymentTapped(viewController: String) {
        let controller = UserPaymentViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func menuBtnTapped() {
        showNavigationDrawer()
    }
    
}
