//
//  DrivingLicenseViewController.swift
//  Medbulance
//
//  Created by Apple on 25/02/21.
//

import UIKit
protocol DrivingLicenseViewControllerDelegate {
    func saveDLTapped()
}

class DrivingLicenseViewController: BaseViewControllerClass,NavigationBarViewDelegate {
    
    
    var selectedIndex = -1
    var deletedIndex = -1
    
    var image:UIImage?
    var licenseImageArray = [UIImage]()
    private lazy var profileImageGallery: Gallery = Gallery(root: self) { [weak self] (img: UIImage) in
        guard let `self`                 = self else { return }
        self.image = img
        let param = ["":""]
       // self.uploadDrivingLicenseApi(params: param)
        self.licenseImageArray.append(self.image!)
        self.itemList.reloadData()
    }
    
    var delegate:DrivingLicenseViewControllerDelegate?
    static var viewControllerId = "DrivingLicenseViewController"
    static var storyBoard = StoryboardConstant.driver

    @IBOutlet weak var fieldContainerView: UIView!
    @IBOutlet weak var navigationBar: NavigationBarView!
    @IBOutlet weak var txtFieldLicenseNumber: UITextField!
    
    let array = ["Upload Front Image","Upload Back Image"]
    
    @IBOutlet weak var itemList: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavigation()
        setInitials()

    }
    
    func setInitials(){
        fieldContainerView.layer.borderWidth = 1
        fieldContainerView.layer.borderColor = UIColor.lightGray.cgColor
        itemList.delegate = self
        itemList.dataSource = self
        let nib = UINib(nibName: "DrivingLicenseTableViewCell", bundle: nil)
        itemList.register(nib, forCellReuseIdentifier: "DrivingLicenseTableViewCell")
        
    }
    
    func setUpNavigation(){
        navigationBar.delegate = self
        navigationBar.lblTitle.text = "Driving License"
        
    }
    
    func backTapped() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSaveAction(_ sender: Any) {
        self.view.endEditing(true)
        if checkValidation(){
            let param = ["DriverId":DriverDetails.sharedInstance.Id,"licensenumber":txtFieldLicenseNumber.text!]
            uploadDrivingLicenseApi(params:param)
        }
        
    }
    
    func checkValidation() -> Bool {
        
        self.view.endEditing(true)
       
        if self.txtFieldLicenseNumber.text!.isEmpty {
            
            self.txtFieldLicenseNumber.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.LICENSE_FIELD_IS_REQUIRED)
            return false
        }
        
        if licenseImageArray.count < 2{
            self.showAlertWithMessage(ConstantStrings.ALERT, "Please select License Image")
            return false
        }
        
        return true
    }
    
}
extension DrivingLicenseViewController:UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = itemList.dequeueReusableCell(withIdentifier: "DrivingLicenseTableViewCell") as! DrivingLicenseTableViewCell
        cell.deleteBtn.tag = indexPath.row
        cell.delegate = self
        
        if selectedIndex == indexPath.row{
            if self.image != nil{
                cell.camImg.isHidden = true
                cell.documentImageView.image = image
            }
           
        }
        
        if deletedIndex == indexPath.row{
            cell.camImg.isHidden = false
            cell.documentImageView.image = nil
            deletedIndex = -1
        }
        
        cell.lblTitle.text = array[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = itemList.cellForRow(at: indexPath) as? DrivingLicenseTableViewCell
        if cell?.documentImageView.image == nil{
            selectedIndex = indexPath.row
            profileImageGallery.show()
        }
   
    }
    
}
extension DrivingLicenseViewController:DrivingLicenseTableViewCellDelegate{
    
    func deleteTapped(index: Int) {
        deletedIndex = index
        itemList.reloadData()
        if index == 1 && self.licenseImageArray.count == 1{
            self.licenseImageArray.remove(at:0)
        }else{
            self.licenseImageArray.remove(at:index)
        }
        
    }
}
extension DrivingLicenseViewController{
    
   
    
    func uploadDrivingLicenseApi(params:[String:String]){
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
       // imageDataArray.removeAll()
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        
        var imageArray = Array<Data>()
        for imageD in self.licenseImageArray{
            let imageData = imageD.jpegData(compressionQuality: 0.5)
            imageArray.append(imageData!)
        }
       
       
     //   imageDataArray.append(imageData as! NSData)
        WebServiceHandler.performMultipartRequest(urlString: kLicenseRegister, fileName: "image", params: params, imageDataArray: imageArray ){(result,error) in
            if result != nil{
                let responseCode = result!["statusCode"]?.int
                if responseCode == 200
                {
                    if let response = result{
                        self.delegate?.saveDLTapped()
                        self.navigationController?.popViewController(animated: true)
                        
                        let message = response["message"]?.string
                        
                       // self.showAlertWithMessage(ConstantStrings.ALERT, message!)
                        if let customer = response["data"]?.dictionary{
                        }
                        // AppHelper.saveUserDetails()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        }
                        
                    }
                }
                else{
                    if let errorMsg = result!["message"]?.string{
                        self.showAlertWithMessage("ALERT", errorMsg)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}
