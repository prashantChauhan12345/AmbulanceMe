//
//  DriverProfileViewController.swift
//  Medbulance
//
//  Created by Apple on 15/03/21.
//

import UIKit

class DriverProfileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
}
