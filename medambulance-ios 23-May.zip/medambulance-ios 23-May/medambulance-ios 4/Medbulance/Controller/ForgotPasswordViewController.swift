//
//  ForgotPasswordViewController.swift
//  Medbulance
//
//  Created by Apple on 08/03/21.
//

import UIKit

class ForgotPasswordViewController: BaseViewControllerClass {
    @IBOutlet weak var txtFieldMobileNo: UITextField!
    
    static var viewControllerId = "ForgotPasswordViewController"
    static var storyBoard = StoryboardConstant.driver
    
    @IBOutlet weak var phoneContainerView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        setInitials()
    }
    
    func setInitials(){
        txtFieldMobileNo.delegate = self
        phoneContainerView.layer.borderWidth = 1
        phoneContainerView.layer.borderColor = UIColor.lightGray.cgColor
    }
    
    @IBAction func btnContinueAction(_ sender: Any) {
      //  let controller = ChangePasswordDriverViewController.instantiateFromStoryBoard()
       // self.push(controller)
        
        let param = ["phone":txtFieldMobileNo.text!]
        
        callForgotPasswordApi(params: param)
    }
    
    
}
extension ForgotPasswordViewController{
    
    func callForgotPasswordApi(params:[String:String]){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPOSTRequest(withURL: kForgotPasswordURL, andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    
                    if let data = result?["data"]?.dictionary{
                        
                        let otp = data["m_otp"]?.stringValue
                        
                        let controller = VerifyOTPViewController.instantiateFromStoryBoard()
                        controller.phone = self.txtFieldMobileNo.text!
                        controller.number = self.txtFieldMobileNo.text!
                        controller.isRegister = false
                        self.push(controller)
                        self.showAlertWithMessage(ConstantStrings.ALERT, "Your OTP is \(otp!)")
                       
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                       // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
 
}
extension ForgotPasswordViewController:UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txtFieldMobileNo {
            var maxLength = 10
            let newLength: Int = textField.text!.count - range.length
            let numberOnly = NSCharacterSet.decimalDigits.inverted
            let strValid = string.rangeOfCharacter(from: numberOnly) == nil
            return (strValid && (newLength < maxLength))
        }else{
            return true
        }
    }
    
}
