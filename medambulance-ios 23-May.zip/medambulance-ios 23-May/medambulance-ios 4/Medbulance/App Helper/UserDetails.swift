//
//  UserDetails.swift
//  Medbulance
//
//  Created by Apple on 17/03/21.
//

import UIKit

class UserDetails: NSObject {
    
    static let sharedInstance = UserDetails()
    
    var Id = ""
    var Name = ""
    var Phone = ""
    var profileImage = ""
}
