//
//  GarageServiceProviderModel.swift
//  Garage Service Provider
//
//  Created by Vikas Kushwaha on 21/09/20.
//  Copyright © 2020 Maxtra Technologies. All rights reserved.
//

import UIKit
import SwiftyJSON

class HospitalModel: NSObject {
    
    var dateCreate = ""
    var hospitalName = ""
    var latitude = ""
    var id = ""
    var longitude = ""
    var dateUpdate = ""
    var userUpdate = ""
    var usercreate = ""
    var address = ""
    var status = ""
    
    class func getAllHospitalListArray(hospitalArray:[JSON]) -> Array<HospitalModel>{
        var hospitalDataArray = Array<HospitalModel>()
        for elements in hospitalArray{
            let dataDetails = HospitalModel.parseHospitalData(details: elements)
            hospitalDataArray.append(dataDetails)
        }
        return hospitalDataArray
    }
    
    class func parseHospitalData(details:JSON) -> HospitalModel{
        let hospitalDetails = HospitalModel()
        hospitalDetails.dateCreate = details["dateCreate"].string ?? ""
      
        hospitalDetails.hospitalName = details["hospitalName"].string ?? ""
        hospitalDetails.id = "\(details["id"].int ?? 0)"
        hospitalDetails.status = "\(details["status"].int ?? 0)"
        hospitalDetails.latitude = "\(details["latitude"].double ?? 0.0)"
       
        hospitalDetails.longitude = "\(details["longitude"].double ?? 0.0)"
        hospitalDetails.dateUpdate = details["dateUpdate"].string ?? ""
        
        hospitalDetails.userUpdate = details["userUpdate"].string ?? ""
        hospitalDetails.usercreate = details["usercreate"].string ?? ""

        hospitalDetails.address = details["address"].string ?? ""
        return hospitalDetails
    }

}
