//
//  Constants.swift
//  HyperCommute
//
//  Created by anurag singh on 04/03/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import Foundation
import UIKit

struct Coordinates {
    let latitude: Double
    let longitude: Double
}

let DeviceType = "ios"
let BASEURL2 = "http://devapi.medambulance.fourbrick.in/"
//let BASEURL = "http://192.168.1.88:5000/"
let BASEURL = "http://devapi.medambulance.fourbrick.in/"
let kLoginURL = BASEURL2 + "driver/login"
let kSignUpURL = BASEURL2 + "driver/Register"
let kLicenseRegister = BASEURL + "Dlicense/licenseregister"
let kLicenseUploadURL = BASEURL2 + "Dlicense/profilePic"
let kAmbulanceDetails = BASEURL + "ambulanceInfo/Info"
let kPersonalDetails = BASEURL + "personal_Details/pId"
let kForgotPasswordURL = BASEURL + "driver/forget/password"
let kChangePasswordURL = BASEURL + "driver/changePassword/"
let kGetDriverProfile = BASEURL + "driver/viewdriver/"
let kDriverStatusUpdate = BASEURL2 + "driver/status/"
let kDriverLocationUpdate = BASEURL2 + "driver/location/"
let kAcceptRequest = BASEURL2 + "driver/acceptbooking"
let kStartTrip = BASEURL2 + "driver/startTrip"
let kEndTrip = BASEURL2 +  "driver/endtrip"

let kMyTrip = BASEURL2 + "driver/mytrip/"
let kUserTrip = BASEURL2 + "user/userride/"
/*http://devapi.medambulance.fourbrick.in/user/userride/604b17991aeb3a0fe43ea1fc */
let kDriverAcceptDeclineTrip = BASEURL2 + "driver/driverResponse"
let kUserCancelTrip = BASEURL2 + "user/usercanceltrip"

let kTotalFare = BASEURL2 + "dashboard/totalfare"

let kBookDriver = BASEURL2 + "user/userbooking"

let kRateCard = BASEURL2 + "card/CategRateCard"

let kGetUserProfile = BASEURL2 + "user/profile/"
let kUpdateUserProfile = BASEURL2 + "user/profileupdate/"

let kUserLastRide = BASEURL2 + "user/lastride/"

let kUserFeedback = BASEURL2 + "user/feedback/lstride/"

let kUpdateDriverProfile = BASEURL2 + "driver/profile/"

let kAmbulanceListURL = "http://134.209.153.34:5077/nearbyHospital"

let kNearByAmbulanceURL = "http://134.209.153.34:5077/getNearAmbulance"
let kAmbulanceServicesURL = BASEURL2 + "dashboard/ambs?ambtype="

let kPaymentAdd = BASEURL2 + "payment/add"
let kpaymentStatusUpdate = BASEURL2 + "payment/statusUpdate/609d00367ddc9b338c2b7dc7"

//http://devapi.medambulance.fourbrick.in/dashboard/ambs?ambtype=SEMIGOVERNMENT

let kResendOtpURL = BASEURL + "user/resend_otp"
let kVerifyOtpURL = BASEURL + "driver/VerifyOTP"
let kGetProfileURL = BASEURL + "user/get_user"
let kUpdateProfileURL = BASEURL + "user/update_profile"
let kGetCouponListURL = BASEURL + "user/get_coupon_list"
//let kChangePasswordURL = BASEURL + "user/change_password"
let kGetServiceProviderListURL = BASEURL + "user/get_service_provider_list"
let kContactUsAboutUsURL = BASEURL + "user/get_cms"
let kGetFaqURL = BASEURL + "user/get_faq"
let kBookAppointementURL = BASEURL + "user/book_service"
let kServiceCategoryURL = BASEURL + "user/service_category"
let kPaymentTypeURL = BASEURL + "user/get_payment_type"
let kBookAppointment = BASEURL + "user/book_service"


//http://182.76.237.227/~maxget/garage/webservie/user/get_service_provider_list


let kServiceURL = BASEURL + "services?filters="
let addRideURL = "http://35.194.73.211:8082/add_ride_request"
let activeRide = "http://35.194.73.211:8082/get_active_ride?rider_id=ashish&rider_hash=42"
let busRoutePlotURL = "https://bus.hypercommute.com/arrival_trips"


