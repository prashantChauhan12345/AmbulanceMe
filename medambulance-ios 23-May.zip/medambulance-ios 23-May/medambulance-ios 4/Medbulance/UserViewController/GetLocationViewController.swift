//
//  GetLocationViewController.swift
//  Medbulance
//
//  Created by MacMini  on 05/03/21.
//

import UIKit

class GetLocationViewController: BaseViewControllerClass {
    
    static var viewControllerId = "GetLocationViewController"
    static var storyBoard = StoryboardConstant.user

    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) { //
            let controller = HomeViewController.instantiateFromStoryBoard()
            self.push(controller)
        }
        
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
