

import Foundation


// Razor pay Keys

let razor_key_id = "rzp_test_oDw757e5auoleh"
let razor_secret_key = "Lpq6MdB30qJzz8tEHsinRGrJ"


enum URLBase {
    static let baseURL = "http://devapi.medambulance.fourbrick.in/user/"
    static let baseURL2 = "http://devapi.medambulance.fourbrick.in/user/"
}

enum appEndPoints{
    static let userRegister = "Register"
    static let VerifyOTP = "VerifyOTP"
}



