//
//  NavigationDrawerProfileTableViewCell.swift
//  driverapp
//
//  Created by MAC on 11/26/19.
//  Copyright © 2019 HyperCommute. All rights reserved.
//

import UIKit

class NavigationDrawerProfileTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var userProfileImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        userProfileImage.layer.cornerRadius = userProfileImage.frame.height/2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
