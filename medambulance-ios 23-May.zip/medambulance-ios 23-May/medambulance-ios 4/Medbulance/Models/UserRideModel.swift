//
//  UserRideModel.swift
//  Medbulance
//
//  Created by MacMini  on 06/05/21.
//

import UIKit
import SwiftyJSON

class UserRideModel: NSObject {

    var dateCreate = ""
    var _id = ""
    var dateUpdate = ""
    var userUpdate = ""
    var usercreate = ""
    var address = ""
    var tripstatus = ""
    var totalprice = ""

    var sorclongitude = ""
    var sorclatitude = ""
    var deslongitude = ""
    var deslatitude = ""
    var sorcaddress = ""
    var desaddress = ""
    
    
    class func getUserRideListArray(userRideArray:[JSON]) -> Array<UserRideModel>{
        var userListDataArray = Array<UserRideModel>()
        for elements in userRideArray{
            let dataDetails = UserRideModel.parseUserRideData(details: elements)
            userListDataArray.append(dataDetails)
        }
        return userListDataArray
    }
    
    
    class func parseUserRideData(details:JSON) -> UserRideModel{
        let userRideDetails = UserRideModel()
        userRideDetails.dateCreate = details["dateCreate"].string ?? ""
        userRideDetails._id = details["_id"].string ?? ""

        userRideDetails.totalprice = "\(details["totalprice"].int ?? 0)"
        userRideDetails.sorclatitude = "\(details["sorclatitude"].double ?? 0.0)"
        userRideDetails.sorclongitude = "\(details["sorclongitude"].double ?? 0.0)"
        userRideDetails.deslatitude = "\(details["deslatitude"].double ?? 0.0)"
        userRideDetails.deslongitude = "\(details["deslongitude"].double ?? 0.0)"
        userRideDetails.dateUpdate = details["updatedAt"].string ?? ""
        userRideDetails.userUpdate = details["userUpdate"].string ?? ""
        userRideDetails.usercreate = details["createdAt"].string ?? ""

        userRideDetails.sorcaddress = details["sorcaddress"].string ?? ""
        userRideDetails.desaddress = details["desaddress"].string ?? ""

        return userRideDetails
    }


    
}
