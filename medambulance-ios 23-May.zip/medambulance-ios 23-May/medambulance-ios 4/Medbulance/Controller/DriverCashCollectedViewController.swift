//
//  DriverCashCollectedViewController.swift
//  Medbulance
//
//  Created by MacMini  on 28/04/21.
//

import UIKit


class DriverCashCollectedViewController: BaseViewControllerClass {
    
    static var viewControllerId = "DriverCashCollectedViewController"
    static var storyBoard = StoryboardConstant.driver

    @IBOutlet weak var confirmcash: UIButton!
    
    var paymentStatusUpdate = [PaymentUpdateStatusModel]()
    
    @IBOutlet weak var lbl_DateTime: UILabel!
    @IBOutlet weak var lbl_BookingNumber: UILabel!
    @IBOutlet weak var lbl_transactionID: UILabel!
    @IBOutlet weak var lbl_transactionNo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    @IBAction func confirmCashCollect(_ sender: Any) {
        
        let param = ["status":"Payment Succesfull"]
        callpaymentStatusUpdate(params: param)
    }
   


}

extension DriverCashCollectedViewController{

    func callpaymentStatusUpdate (params:[String:String]){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPATCHRequest(withURL: kpaymentStatusUpdate, andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                 
                    if let data = result?["statusPayment"]?.array{
                        
                        self.paymentStatusUpdate = PaymentUpdateStatusModel.getPaymentUpdateStatusArray(userPaymentUpdataStatusArray: data)
                    }
                    
                    let message = result?["message"]?.stringValue ?? ""
                    self.showAlertWithMessage(ConstantStrings.ALERT, message)
                }
                else{
                    if let message = result?["message"]?.string{
                       // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}
