//
//  DrivingLicenseTableViewCell.swift
//  Medbulance
//
//  Created by Apple on 25/02/21.
//

import UIKit
protocol DrivingLicenseTableViewCellDelegate {
    func deleteTapped(index:Int)
}
class DrivingLicenseTableViewCell: UITableViewCell {

    @IBOutlet weak var camImg: UIImageView!
    @IBOutlet weak var documentImageView: UIImageView!

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imageContainerView: UIView!
    @IBOutlet weak var deleteBtn: UIButton!
    
    var delegate:DrivingLicenseTableViewCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setInitials()
    }
    
    func setInitials(){
        imageContainerView.layer.borderWidth = 1
        imageContainerView.layer.borderColor = UIColor.lightGray.cgColor
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func deleteBtnAction(_ sender: UIButton) {
        self.delegate?.deleteTapped(index: sender.tag)
        
    }
    
}
