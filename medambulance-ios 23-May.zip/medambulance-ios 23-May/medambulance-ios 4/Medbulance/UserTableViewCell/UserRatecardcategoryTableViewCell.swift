//
//  UserRatecardcategoryTableViewCell.swift
//  Medbulance
//
//  Created by MacMini  on 09/03/21.
//

import UIKit

class UserRatecardcategoryTableViewCell: UITableViewCell {
    @IBOutlet weak var view_pink: UIView!
    @IBOutlet weak var view_category: UIView!
    @IBOutlet weak var lbl_category: UILabel!
 
    override func awakeFromNib() {
        super.awakeFromNib()
        
        view_pink.layer.cornerRadius = 20
        view_pink.clipsToBounds = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
