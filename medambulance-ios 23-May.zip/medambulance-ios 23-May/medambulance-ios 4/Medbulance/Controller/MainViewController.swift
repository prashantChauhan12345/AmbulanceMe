//
//  MainViewController.swift
//  Medbulance
//
//  Created by Apple on 13/04/21.
//

import UIKit

class MainViewController: BaseViewControllerClass {
    
    static var viewControllerId = "MainViewController"
    static var storyBoard = StoryboardConstant.main

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        
        setMainController()

        // Do any additional setup after loading the view.
    }
    
    
    func setMainController(){
        if UserDetails.sharedInstance.Id == ""{
            if DriverDetails.sharedInstance.Id == ""{
                //sendTo main Controller
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "WelcomeNavController")
                redirectToMainNavRVC(currentVC: controller)
                
            }else{
                let storyboard = UIStoryboard(name: "Driver", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "DriverNavHomeVC")
            
                redirectToMainNavRVC(currentVC: controller)
            }
        }else{
            let storyboard = UIStoryboard(name: "User", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "UserNavHomeVC")
           
            redirectToMainNavRVC(currentVC: controller)
        }
    }
    


}
