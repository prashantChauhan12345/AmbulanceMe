//
//  TotalFAreDetailViewController.swift
//  Medbulance
//
//  Created by MacMini  on 27/04/21.
//

import UIKit

class TotalFAreDetailViewController: UIViewController {
    
    @IBOutlet weak var lbl_AmountDetail: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.isNavigationBarHidden = true
    }
    
    @IBAction func action_CTPAY(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "UserPaymentViewController") as? UserPaymentViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
}
