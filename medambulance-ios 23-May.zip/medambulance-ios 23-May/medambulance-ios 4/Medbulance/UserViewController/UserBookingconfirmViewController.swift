//
//  UserBookingconfirmViewController.swift
//  Medbulance
//
//  Created by MacMini  on 09/03/21.
//

import UIKit

class UserBookingconfirmViewController: BaseViewControllerClass {
    
    static var viewControllerId = "UserBookingconfirmViewController"
    static var storyBoard = StoryboardConstant.user
    
    var driverId = ""
    var sourceLat = 0.0
    var sourceLong = 0.0
    var desLat = 0.0
    var desLong = 0.0
    var otp = ""
    var sourceAddress = ""
    var destAddress = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        print(driverId)

        // Do any additional setup after loading the view.
    }
    

    
    @IBAction func trackAmbulanceAction(_ sender: Any) {
        
        DispatchQueue.main.async {
         
            let controller = TrackAmbulanceViewController.instantiateFromStoryBoard()
            controller.sourceLat = self.sourceLat
            controller.sourceLong = self.sourceLong
            controller.desLat = self.desLat
            controller.desLong = self.desLong
            controller.driverId = self.driverId
            controller.otp = self.otp
            controller.sourceAddress = self.sourceAddress
            controller.destAddress = self.destAddress
            
            self.push(controller)
        }
       
    }
    
}
