//
//  LocationsTableViewCell.swift
//  HyperCommute
//
//  Created by MAC on 12/12/19.
//  Copyright © 2019 MAC. All rights reserved.
//

import UIKit

class LocationsTableViewCell: UITableViewCell {
    @IBOutlet weak var primaryAddressLbl: UILabel!
    @IBOutlet weak var secondryAddressLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
