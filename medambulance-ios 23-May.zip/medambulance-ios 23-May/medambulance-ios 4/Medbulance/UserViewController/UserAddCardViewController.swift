//
//  UserAddCardViewController.swift
//  Medbulance
//
//  Created by MacMini  on 12/03/21.
//

import UIKit
import Stripe
import SwiftyJSON
protocol UserAddCardViewControllerDelegate {
    func refreshData()
}
class UserAddCardViewController: BaseViewControllerClass, UITextFieldDelegate {
    
    static var viewControllerId = "UserAddCardViewController"
    static var storyBoard = StoryboardConstant.user
    
    var delegate:UserAddCardViewControllerDelegate?

    @IBOutlet weak var txtfield_cardnumber: UITextField!
    @IBOutlet weak var txtfield_cvv: UITextField!
    @IBOutlet weak var view_payment: UIView!
    @IBOutlet weak var txtFieldExpDate: UITextField!
    @IBOutlet weak var txtField_CardHoldername: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        txtfield_cardnumber.delegate = self
        txtField_CardHoldername.delegate = self
        txtfield_cvv.delegate = self
        txtFieldExpDate.delegate = self
        view_payment.addBottomShadow()
        
    }
  
    
   
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == txtfield_cardnumber {
            let maxLength = 16
            let newLength: Int = textField.text!.count - range.length
            let numberOnly = NSCharacterSet.decimalDigits.inverted
            let strValid = string.rangeOfCharacter(from: numberOnly) == nil
            return (strValid && (newLength < maxLength))
        } else if textField == txtfield_cvv{
            let maxLength = 3
            let newLength: Int = textField.text!.count - range.length
            let numberOnly = NSCharacterSet.decimalDigits.inverted
            let strValid = string.rangeOfCharacter(from: numberOnly) == nil
            return (strValid && (newLength < maxLength))
        }else if textField == txtFieldExpDate{
            
            guard let oldText = textField.text, let r = Range(range, in: oldText) else {
                    return true
                }
                let updatedText = oldText.replacingCharacters(in: r, with: string)

                if string == "" {
                    if updatedText.count == 2 {
                        textField.text = "\(updatedText.prefix(1))"
                        return false
                    }
                } else if updatedText.count == 1 {
                    if updatedText > "1" {
                        return false
                    }
                } else if updatedText.count == 2 {
                    if updatedText <= "12" { //Prevent user to not enter month more than 12
                        textField.text = "\(updatedText)/" //This will add "/" when user enters 2nd digit of month
                    }
                    return false
                } else if updatedText.count == 5 {
                    self.expDateValidation(dateStr: updatedText)
                } else if updatedText.count > 5 {
                    return false
                }
        }
        return true
        
    }
    
    
    
    //    Check validation
    func checkValidation() -> Bool {
        
        self.view.endEditing(true)
        if self.txtfield_cardnumber.text!.isEmpty {
            
            self.txtfield_cardnumber.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Card Number is Required")
            return false
        }
        
        if self.txtField_CardHoldername.text!.isEmpty {
            
            self.txtField_CardHoldername.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "CardHolder Name is Required")
            return false
        }
        
        if self.txtFieldExpDate.text!.isEmpty {
            
            self.txtFieldExpDate.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "Expiry Date is Required")
            return false
        }
        
        if self.txtfield_cvv.text!.isEmpty {
            
            self.txtfield_cvv.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, "CVV is Required")
            return false
        }
        
        return true
    }
    
    
    @IBAction func btnBackArrowAction(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnAddCardAction(_ sender: Any) {
        
        if checkValidation(){
            self.delegate?.refreshData()
          //  self.navigationController?.popViewController(animated: true)
            let cardNumber = self.txtfield_cardnumber.text ?? ""
            let cvv = self.txtfield_cvv.text ?? ""
            let expiryDate = self.txtFieldExpDate.text ?? ""
            let month = expiryDate.components(separatedBy: "/")[0]
            let year = expiryDate.components(separatedBy: "/")[1]
            
           // self.addNewCard(cardNumber: cardNumber, month, year, cvv)
            self.addNewCard(cardNumber: cardNumber, month: UInt(month)!, year: UInt(year)!, cvv: cvv)
        }
        
    }
    
    
    func expDateValidation(dateStr:String) {

        let currentYear = Calendar.current.component(.year, from: Date()) % 100   // This will give you current year (i.e. if 2019 then it will be 19)
        let currentMonth = Calendar.current.component(.month, from: Date()) // This will give you current month (i.e if June then it will be 6)

        let enteredYear = Int(dateStr.suffix(2)) ?? 0 // get last two digit from entered string as year
        let enteredMonth = Int(dateStr.prefix(2)) ?? 0 // get first two digit from entered string as month
        print(dateStr) // This is MM/YY Entered by user

        if enteredYear > currentYear {
            if (1 ... 12).contains(enteredMonth) {
                print("Entered Date Is Right")
            } else {
                print("Entered Date Is Wrong")
            }
        } else if currentYear == enteredYear {
            if enteredMonth >= currentMonth {
                if (1 ... 12).contains(enteredMonth) {
                   print("Entered Date Is Right")
                } else {
                   print("Entered Date Is Wrong")
                }
            } else {
                print("Entered Date Is Wrong")
            }
        } else {
           print("Entered Date Is Wrong")
        }

    }
    
}
extension UserAddCardViewController{
    
    func addNewCard(cardNumber : String, month : UInt,year : UInt,cvv : String){
        let cardParams = STPCardParams()
        cardParams.number = cardNumber
        cardParams.expMonth = month
        cardParams.expYear = year
        cardParams.cvc = cvv
        
        STPAPIClient.shared.createToken(withCard: cardParams) { (token: STPToken?, error: Error?) in
            guard let stripeToken = token, error == nil else {
               
                showAlertWithCompletion(title: "Error!", message: error!.localizedDescription, buttonTitle: "OK", vc: self, completion: { (alertAction) -> (Void) in
                  
                })
                return
            }
            print(stripeToken)
            /*
            let url = URL(string:BASEURL+SaveCard)
            print(url!)
            var request = URLRequest(url: url!)
            let parameter: Parameters =
                [
                    "user_id":UserDefaults.standard.value(forKey: "userId") as? String ?? "",
                    "holder_name":self.nameTF.text ?? "",
                    "expiry_month":"\(stripeToken.card!.expMonth)",
                    "expiry_year": "\(stripeToken.card!.expYear)",
                    
                    "last_digits":"\(stripeToken.card!.last4)",
                    "brand":"\(STPCard.string(from: stripeToken.card!.brand))",
                    "card_token":"\(stripeToken.card!.stripeID)",
                    "pay_token":stripeToken.tokenId
                ]
            self.selectedCrdToken = (stripeToken.card!.stripeID)
            print(parameter)
            AF.request(url as! URLConvertible, method: .post, parameters: parameter, encoding: JSONEncoding.default).responseJSON { response in
                
                
                switch response.result {
                case .success(let value):
                    if let JSON = value as? [String: Any]
                    {
                        let status = JSON["status"] as! String
                        print(status)
                        var messages = JSON["msg"] as? String
                        print(JSON)
                        
                        if(status == "200")
                        {
                            self.showToast(message: messages ?? "saved")
                            
                            
                            self.hideActivityLoader()
                            self.getCardsList()
                            self.nameTF.text = ""
                            self.cardNumberTf.text = ""
                            self.expTf.text = ""
                            self.cvvTF.text = ""
                            self.completePaymentApi()
                            
                            
                            //                                         if let userData = JSON["block_user_data"] as? NSArray
                            //                                         {
                            //                                        self.arrTableViewDatSource = NSMutableArray(array: userData) as [AnyObject]
                            //                                       }
                            //
                            // self.tblViewOutlet.reloadData()
                            
                        }
                        else
                        {
                            self.showToast(message: messages!)
                            self.hideActivityLoader()
                        }
                    }
                case .failure(_):
                    print("failed")
                    self.hideActivityLoader()
                    break
                }
                
            }
        */
            
        }
        
    }
    
    

}
