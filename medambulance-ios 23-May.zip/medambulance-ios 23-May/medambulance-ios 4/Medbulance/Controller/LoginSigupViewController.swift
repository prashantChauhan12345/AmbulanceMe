//
//  LoginSigupViewController.swift
//  Medbulance
//
//  Created by Apple on 23/02/21.

import UIKit
import CountryPickerView

class LoginSigupViewController: BaseViewControllerClass {
    
    static var viewControllerId = "LoginSigupViewController"
    static var storyBoard = StoryboardConstant.main
    
    let viewCornerRadius:CGFloat = 5
    
    @IBOutlet weak var txtFieldMobileNumberLogin: UITextField!
    
    @IBOutlet weak var txtFieldPasswordLogin: UITextField!
    
    @IBOutlet weak var btnRememberMe: UIButton!
    @IBOutlet weak var txtFieldNameSignUp: UITextField!
    @IBOutlet weak var txtFieldMobileNumberSignUp: UITextField!
    @IBOutlet weak var txtFieldEmail: UITextField!
    @IBOutlet weak var txtFieldPassword: UITextField!
    @IBOutlet weak var selectCountryView: CountryPickerView!
    @IBOutlet weak var txtFieldConfirmPassword: UITextField!
    
    @IBOutlet weak var internalViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var signupView: UIView!
    @IBOutlet weak var scrollViewOutlet: UIScrollView!
    
    @IBOutlet var signupContainerView: [UIView]!
    
    @IBOutlet weak var scrollingContainerView: UIView!
    @IBOutlet weak var btnSignUp: UIButton!
    
    @IBOutlet weak var btnLogin: UIButton!
    
    
    @IBOutlet weak var lblTitleLogin: UILabel!
    @IBOutlet weak var lblTitleSignUp: UILabel!
    @IBOutlet weak var lblSliderLogin: UILabel!
    @IBOutlet weak var lblSliderSignUp: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setInitials()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    
    func setInitials(){
        signupView.isHidden = true
        internalViewHeightConstraint.constant = 393
        selectCountryView.delegate = self
        selectCountryView.dataSource = self
        txtFieldMobileNumberSignUp.delegate = self
        txtFieldMobileNumberLogin.delegate = self
       // ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading..")
        
        for singleView in signupContainerView{
            singleView.layer.cornerRadius = viewCornerRadius
            singleView.layer.borderWidth = 1
            singleView.layer.borderColor = UIColor.lightGray.cgColor
        }
        
        btnLogin.layer.cornerRadius = viewCornerRadius
        btnSignUp.layer.cornerRadius = viewCornerRadius
    }
    
    
    //    Check validation
    func checkSignUpValidation() -> Bool {
        
        self.view.endEditing(true)
        if self.txtFieldNameSignUp.text!.isEmpty {
            
            self.txtFieldNameSignUp.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.NAME_FIELD_IS_REQUIRED)
            return false
        }
        
        if self.txtFieldMobileNumberSignUp.text!.isEmpty {
            
            self.txtFieldMobileNumberSignUp.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.MOBILE_NO_FIELD_IS_REQUIRED)
            return false
        }
        
        if (self.txtFieldMobileNumberSignUp.text?.isValid(regex: .phone))!{
            
        }else{
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PLEASE_ENTER_VALID_MOBILE)
            return false
        }
        
        if self.txtFieldEmail.text!.isEmpty {
            
            self.txtFieldEmail.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.EMAIL_FIELD_IS_REQUIRED)
            return false
        }
        
    
        if self.txtFieldEmail.text!.isValidEmail(){
            
        }else{
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PLEASE_ENTER_VALID_EMAIL)
            return false
        }
    
        
        if self.txtFieldPassword.text!.isEmpty {
            
            self.txtFieldPassword.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PASSWORD_FIELD_IS_REQUIRED)
            return false
        }
        
        if self.txtFieldPassword.text!.count < 0 {
            
            self.txtFieldPassword.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PASSWORD_FIELD_MIN_SIX)
            return false
        }
        
        if self.txtFieldConfirmPassword.text!.isEmpty {
            
            self.txtFieldConfirmPassword.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.CONFIRM_PASSWORD_FIELD_IS_REQUIRED)
            return false
        }
        
        if self.txtFieldPassword.text! != txtFieldConfirmPassword.text!{
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PASSWORD_AND_CONFIRM_PASSWORD_DIDNOT_MATCH)
            return false
        }
        return true
    }
    
    
    func checkLoginValidation() -> Bool {
        
        self.view.endEditing(true)
       
        if self.txtFieldMobileNumberLogin.text!.isEmpty {
            
            self.txtFieldMobileNumberLogin.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.MOBILE_NO_FIELD_IS_REQUIRED)
            return false
        }
        
        if (self.txtFieldMobileNumberLogin.text?.isValid(regex: .phone))!{
            
        }else{
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PLEASE_ENTER_VALID_MOBILE)
            return false
        }
        

        if self.txtFieldPasswordLogin.text!.isEmpty {
            
            self.txtFieldPasswordLogin.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PASSWORD_FIELD_IS_REQUIRED)
            return false
        }
        return true
    }
    
    
    @IBAction func loginAction(_ sender: Any) {
        lblTitleLogin.textColor = Colors.themeColor
        lblSliderLogin.backgroundColor = Colors.themeColor
        lblTitleSignUp.textColor = UIColor.darkGray
        lblSliderSignUp.backgroundColor = UIColor.darkGray
        
        scrollViewOutlet.scrollToTop()
        internalViewHeightConstraint.constant = 393
        let transition = CATransition()
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromLeft
        loginView.layer.add(transition, forKey: nil)
        
        loginView.isHidden = false
        signupView.isHidden = true
        //scrollingContainerView.addSubview(myVC.view)
    }
    
    @IBAction func signupAction(_ sender: Any) {
        lblTitleLogin.textColor = UIColor.darkGray
        lblSliderLogin.backgroundColor = UIColor.darkGray
        lblTitleSignUp.textColor = Colors.themeColor
        lblSliderSignUp.backgroundColor = Colors.themeColor
        
        scrollViewOutlet.scrollToTop()
        internalViewHeightConstraint.constant = 533
        let transition = CATransition()
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromRight
        signupView.layer.add(transition, forKey: nil)
        
        loginView.isHidden = true
        signupView.isHidden = false
    }
    
    @IBAction func btnLoginAction(_ sender: Any) {
      //  let controller = DriverVerificationViewController.instantiateFromStoryBoard()
      //  self.push(controller)
        
        if checkLoginValidation(){
            let param = ["phone":txtFieldMobileNumberLogin.text!,"password":txtFieldPasswordLogin.text!]
            callLoginApi(params: param)
        }
        
    }
    
    @IBAction func btnSignUpAction(_ sender: Any) {
        
        if checkSignUpValidation(){
            let param = ["phone":txtFieldMobileNumberSignUp.text!,"email":txtFieldEmail.text!,"password":txtFieldPassword.text!,"drivername":txtFieldNameSignUp.text!,"deviceType":DeviceType]
            callSignUpApi(params: param)
        }
    }
    
    
    @IBAction func btnRememberMeAction(_ sender: Any) {
        
        if btnRememberMe.image(for: .normal) == UIImage(named: "unclicked"){
            btnRememberMe.setImage(UIImage(named: "clicked"), for: .normal)
        }else{
            btnRememberMe.setImage(UIImage(named: "unclicked"), for: .normal)
        }
    }
    
    @IBAction func btnLoginShowPassword(_ sender: Any) {
        txtFieldPasswordLogin.isSecureTextEntry.toggle()
    }
    
    @IBAction func forgotPasswordAction(_ sender: Any) {
        let controller = ForgotPasswordViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSignUpShowPassword(_ sender: Any) {
        txtFieldPassword.isSecureTextEntry.toggle()
    }
    
    
}
extension UIScrollView {
    func scrollToTop() {
        let desiredOffset = CGPoint(x: 0, y: -contentInset.top)
        setContentOffset(desiredOffset, animated: true)
    }
}
extension LoginSigupViewController:CountryPickerViewDelegate,CountryPickerViewDataSource,UITextFieldDelegate{
    
    func countryPickerView(_ countryPickerView: CountryPickerView, didSelectCountry country: Country) {
        print("\(country.name) \(country.code) \(country.phoneCode)")
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txtFieldMobileNumberSignUp || textField == txtFieldMobileNumberLogin{
            var maxLength = 10
            let newLength: Int = textField.text!.count - range.length
            let numberOnly = NSCharacterSet.decimalDigits.inverted
            let strValid = string.rangeOfCharacter(from: numberOnly) == nil
            return (strValid && (newLength < maxLength))
        }else{
            return true
        }
    }
    
}
extension LoginSigupViewController{
    
    func callSignUpApi(params:[String:String]){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPOSTRequest(withURL: kSignUpURL, andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    if let data = result?["data"]?.dictionary{
                        
                        let userId = data["_id"]?.stringValue
                        let otp = data["m_otp"]?.stringValue
                        let driverName = data["drivername"]?.stringValue
                        DriverDetails.sharedInstance.Id = userId!
                        print(userId)
                        let controller = VerifyOTPViewController.instantiateFromStoryBoard()
                        controller.number = self.txtFieldMobileNumberSignUp.text!
                        controller.isRegister = true
                        
                        self.push(controller)
                        self.showAlertWithMessage(ConstantStrings.ALERT, "Your OTP is \(otp!)")
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                       // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
    
    func callLoginApi(params:[String:String]){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPOSTRequest(withURL: kLoginURL, andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    
                    if let data = result?["data"]?.dictionary{
                        
                        if let driverData = data["driver"]?.dictionary{
                            
                            if let userId = driverData["_id"]?.stringValue{
                                DriverDetails.sharedInstance.Id = userId
                            }
                            
                            if let email = driverData["email"]?.stringValue{
                                DriverDetails.sharedInstance.Email = email
                            }
                            if let phone = driverData["phone"]?.stringValue{
                                DriverDetails.sharedInstance.Phone = phone
                            }
                            if let name = driverData["name"]?.stringValue{
                                DriverDetails.sharedInstance.Id = name
                            }
                            
                            AppHelper.saveDriverDetails()
                            
                            let controller = DriverVerificationViewController.instantiateFromStoryBoard()
                            self.push(controller)
                        }
                        
                       // self.showAlertWithMessage(ConstantStrings.ALERT, "Your OTP is \(otp!)")
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                       // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}
