//
//  AmbulanceServiceModel.swift
//  Medbulance
//
//  Created by Apple on 31/03/21.
//

import UIKit
import SwiftyJSON

class AmbulanceServiceModel: NSObject {
    
    
      var __v = ""
      var createdAt = ""
      var name = ""
      var _id = ""
      var ambtype = ""
      var services = [String]()
      var updatedAt = ""
      var price = ""
    
    
    class func getAllAmbulanceListArray(ambulanceArray:[JSON]) -> Array<AmbulanceServiceModel>{
        var ambulanceDataArray = Array<AmbulanceServiceModel>()
        for elements in ambulanceArray{
            let dataDetails = AmbulanceServiceModel.parseAmbulanceData(details: elements)
            ambulanceDataArray.append(dataDetails)
        }
        return ambulanceDataArray
    }
    
    class func parseAmbulanceData(details:JSON) -> AmbulanceServiceModel{
        let ambulanceDetails = AmbulanceServiceModel()
        ambulanceDetails.name = details["name"].string ?? ""
      
        ambulanceDetails.__v = details["__v"].string ?? ""
        ambulanceDetails.createdAt = "\(details["createdAt"].string ?? "")"
        ambulanceDetails._id = "\(details["_id"].string ?? "")"
        ambulanceDetails.ambtype = "\(details["ambtype"].string ?? "")"
       
        ambulanceDetails.updatedAt = "\(details["updatedAt"].string ?? "")"
        
        if let servicesArray = details["services"].array{
            for i in servicesArray{
                ambulanceDetails.services.append(i.string ?? "")
            }
        }
     
        ambulanceDetails.price = "\(details["price"].int ?? 0)"
        
        return ambulanceDetails
    }

}
