//
//  DriverVerificationViewController.swift
//  Medbulance
//
//  Created by Apple on 25/02/21.
//

import UIKit

class DriverVerificationViewController: BaseViewControllerClass,DrivingLicenseViewControllerDelegate,PersonalIdViewControllerDelegate {
    
    static var viewControllerId = "DriverVerificationViewController"
    static var storyBoard = StoryboardConstant.driver
    
    
    @IBOutlet weak var itemList: UITableView!
    
    var isDrivingUploaded = 0
    var isPersonalIdUploaded = 0

    
    let verfiyArray = ["Driving License","Personal Id Card","Ambulance Details"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setInitials()
    }
    
    func setInitials(){
        itemList.delegate = self
        itemList.dataSource = self
    }
    
    func saveDLTapped() {
        self.isDrivingUploaded = 1
        itemList.reloadData()
    }
    func savePersonalTapped() {
        self.isPersonalIdUploaded = 1
        itemList.reloadData()
    }
    
}
extension DriverVerificationViewController:UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return verfiyArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = itemList.dequeueReusableCell(withIdentifier: "VerificationTableViewCell") as! VerificationTableViewCell
        cell.imgTick.isHidden = true
        if indexPath.row == 0{
            if isDrivingUploaded == 1{
                cell.imgTick.isHidden = false
            }
            
        }
        if indexPath.row == 1{
            if isPersonalIdUploaded == 1{
                cell.imgTick.isHidden = false
            }
        }
            
        cell.lblTitle.text = verfiyArray[indexPath.row]
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row  == 0{
            let controller = DrivingLicenseViewController.instantiateFromStoryBoard()
            controller.delegate = self
            self.push(controller)
        }else if indexPath.row == 1{
            let controller = PersonalIdViewController.instantiateFromStoryBoard()
            controller.delegate = self
            self.push(controller)
        }else{
            let controller = AmbulanceDetailsViewController.instantiateFromStoryBoard()
            self.push(controller)
        }
    }
    
    
    
}
