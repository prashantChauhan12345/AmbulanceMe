//
//  VerifiedViewController.swift
//  Medbulance
//
//  Created by Apple on 02/03/21.
//

import UIKit

class VerifiedViewController: BaseViewControllerClass {
    
    static var viewControllerId = "VerifiedViewController"
    static var storyBoard = StoryboardConstant.driver

    override func viewDidLoad() {
        super.viewDidLoad()
        /*
        */
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnLoginNowAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = LoginSigupViewController.instantiateFromStoryBoard()
        //redirectToMainNavRVC(currentVC: controller)
        self.push(controller)
    }
    

}
