//
//  SideMenuNavigationBar.swift
//  Medbulance
//
//  Created by Apple on 06/03/21.
//

import UIKit
protocol SideMenuNavigationBarDelegate {
    func menuBtnTapped()
}
class SideMenuNavigationBar: UIView {
    
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var contentContainerView: UIView!
    var delegate:SideMenuNavigationBarDelegate?
    
    override init(frame:CGRect){
        super.init(frame: frame)
        commitInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commitInit()
    }
    
    func commitInit(){
        Bundle.main.loadNibNamed("SideMenuNavigationBar", owner: self, options: nil)
        contentContainerView.addBottomShadow()
        addSubview(containerView)
    }
    
    

    @IBAction func btnSideMenuAction(_ sender: Any) {
        self.delegate?.menuBtnTapped()
    }
    

   
}
