//
//  SideBarView.swift
//  driverapp
//
//  Created by MAC on 11/3/21.
//  Copyright © 2021 Medbulance. All rights reserved.


import UIKit
protocol SideBarViewDelegate {
    func profileTapped(viewController:String)
    func homeTapped(viewController:String)
    func myProfileTapped(viewController:String)
    func myTripsTapped(viewController:String)
    func notificationsTapped(viewController:String)
    func onlineSupportTapped(viewController:String)
}

protocol SideBarViewUserDelegate {
    func profileTapped(viewController:String)
    func bookYourRideTapped(viewController:String)
    func yourRideTapped(viewController:String)
    func rateCardTapped(viewController:String)
    func supportTapped(viewController:String)
    func aboutTapped(viewController:String)
    func paymentTapped(viewController:String)
}

protocol SideBarViewLogoutDelegate {
    func logoutTapped()
}
class SideBarView: UIView {
    
    @IBOutlet weak var logoutImageView: UIImageView!
    @IBOutlet weak var tableContainerView: UIView!
    @IBOutlet weak var blackView: UIView!
    @IBOutlet weak var itemList: UITableView!
    var logoutDelegate:SideBarViewLogoutDelegate?
    var delegate:SideBarViewDelegate?
    var delegateUser:SideBarViewUserDelegate?
    
    var isUser = false
    
    var lists = ["","Home","My Profile","My Trips","Notification","Online Support"]
    var imageList = ["","taxi","profile","ratecard","notification","about"]
    
    var listsUser = ["","Book Your Ride","Your Ride","Rate Card","Support","About","Payment"]
    var imageListUser = ["","taxi","yourride","ratecard","support","about","payment"]
    
    var previousViewController = ""
    // MARK: init
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        if self.subviews.count == 0 {
            setup()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    //    override func awakeFromNib() {
    //        setup()
    //    }
    
    private func setup() {
        if let view = Bundle.main.loadNibNamed("SideBarView", owner: self, options: nil)?.first as? UIView {
            view.frame = bounds
            view.autoresizingMask = UIView.AutoresizingMask(rawValue: UIView.AutoresizingMask.RawValue(UInt8(UIView.AutoresizingMask.flexibleWidth.rawValue) | UInt8(UIView.AutoresizingMask.flexibleHeight.rawValue)))
            
            view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
            self.backgroundColor = UIColor.clear
            addSubview(view)
           
            itemList.isHidden = false
            itemList.delegate = self
            itemList.dataSource = self
            
            let nib1 = UINib(nibName: "NavigationDrawerProfileTableViewCell", bundle: nil)
            itemList.register(nib1, forCellReuseIdentifier: "NavigationDrawerProfileTableViewCell")
            let nib2 = UINib(nibName: "NavigationDrawerTableViewCell", bundle: nil)
            itemList.register(nib2, forCellReuseIdentifier: "NavigationDrawerTableViewCell")
            
            //    showSideMenu()
        }
    }
    
    // MARK:- Table View Delegates
    
    @IBAction func backButtonTapped(_ sender: Any) {
        hideSideMenu()
    }
    
    func showSideMenu() {
        /*
         let transition = CATransition()
         transition.type = CATransitionType.push
         transition.subtype = CATransitionSubtype.fromLeft
         tableContainerView.layer.add(transition, forKey: nil)
         */
    }
    
    func hideSideMenu() {
        //itemList.layer.removeAllAnimations()
        /*
         let transition = CATransition()
         transition.type = CATransitionType.push
         transition.subtype = CATransitionSubtype.fromRight
         self.tableContainerView.layer.add(transition, forKey: nil)
         self.tableContainerView.layer.removeAllAnimations()
         */
        self.removeFromSuperview()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if touch?.view != itemList{
            hideSideMenu()
        }
    }
    
    
    @IBAction func tapGestureTapped(_ sender: Any) {
        self.removeFromSuperview()
    }
    
    @IBAction func logoutAction(_ sender: Any) {
        hideSideMenu()
        self.logoutDelegate?.logoutTapped()
    }
    
}
extension SideBarView:UITableViewDataSource,UITableViewDelegate{
    // TableView Delegates.
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isUser {
            return listsUser.count
        }else{
            return lists.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0{
            let cell = itemList.dequeueReusableCell(withIdentifier: "NavigationDrawerProfileTableViewCell") as? NavigationDrawerProfileTableViewCell
            
            if isUser{
                cell?.lblTitle.text = UserDetails.sharedInstance.Phone
                cell?.nameLabel.text = UserDetails.sharedInstance.Name
            }else{
                cell?.lblTitle.text = DriverDetails.sharedInstance.Phone
                cell?.nameLabel.text = DriverDetails.sharedInstance.Name
            }
            cell?.selectionStyle = .none
            return cell!
        }else{
            let cell = itemList.dequeueReusableCell(withIdentifier: "NavigationDrawerTableViewCell") as? NavigationDrawerTableViewCell
            if isUser{
                cell?.titleLbl.text = listsUser[indexPath.row]
                cell?.titleImage.image = UIImage(named: imageListUser[indexPath.row])
            }else{
                cell?.titleLbl.text = lists[indexPath.row]
                cell?.titleImage.image = UIImage(named: imageList[indexPath.row])
            }
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0{
            return 95
        }else{
            return 45
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        if isUser{
            switch indexPath.row{
            case 0:
                self.delegateUser?.profileTapped(viewController: previousViewController)
            case 1:
                self.delegateUser?.bookYourRideTapped(viewController: previousViewController)
            case 2:
                self.delegateUser?.yourRideTapped(viewController: previousViewController)
            case 3:
                self.delegateUser?.rateCardTapped(viewController: previousViewController)
            case 4:
                self.delegateUser?.supportTapped(viewController: previousViewController)
            case 5:
                self.delegateUser?.aboutTapped(viewController: previousViewController)
                
            case 6:
                self.delegateUser?.paymentTapped(viewController: previousViewController)
            default:
                print("Tapped")
            }
        }else{
            switch indexPath.row{
            case 0:
                print("This")
            case 1:
                self.delegate?.homeTapped(viewController: previousViewController)
            case 2:
                self.delegate?.myProfileTapped(viewController: previousViewController)
            case 3:
                self.delegate?.myTripsTapped(viewController: previousViewController)
            case 4:
                self.delegate?.notificationsTapped(viewController: previousViewController)
            case 5:
                self.delegate?.onlineSupportTapped(viewController: previousViewController)
            default:
                print("Tapped")
            }
        }
 
        hideSideMenu()
    }
}
