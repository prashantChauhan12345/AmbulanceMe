//
//  UserratecardDetailTableViewCell.swift
//  Medbulance
//
//  Created by MacMini  on 09/03/21.
//

import UIKit

class UserratecardDetailTableViewCell: UITableViewCell {
    @IBOutlet weak var lbl_detail: UILabel!
    @IBOutlet weak var view_detail: UIView!

    @IBOutlet weak var lblDesc: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
