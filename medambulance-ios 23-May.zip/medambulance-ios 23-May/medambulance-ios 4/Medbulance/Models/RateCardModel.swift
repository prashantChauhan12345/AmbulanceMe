//
//  RateCardModel.swift
//  Medbulance
//
//  Created by MacMini  on 04/05/21.
//

import UIKit
import SwiftyJSON

class RateCardModel: NSObject {

    var _id = ""
    var selectCategory = ""
    var TotalFare = ""
    var ExtraCharges = ""
    var updatedAt = ""
    var __v = ""
    

  
  
  class func getAllRateCardListArray(ambulanceArray:[JSON]) -> Array<RateCardModel>{
      var ambulanceDataArray = Array<RateCardModel>()
      for elements in ambulanceArray{
          let dataDetails = RateCardModel.parseRateCardData(details: elements)
          ambulanceDataArray.append(dataDetails)
      }
      return ambulanceDataArray
  }
  
  class func parseRateCardData(details:JSON) -> RateCardModel{
      let rateCardDetails = RateCardModel()
    
    rateCardDetails.__v = details["__v"].string ?? ""
    rateCardDetails._id = "\(details["_id"].string ?? "")"
    rateCardDetails.selectCategory = "\(details["selectCategory"].string ?? "")"
     
    rateCardDetails.updatedAt = "\(details["updatedAt"].string ?? "")"
      
    rateCardDetails.TotalFare = "\(details["TotalFare"].string ?? "")"
    
    rateCardDetails.ExtraCharges = "\(details["ExtraCharges"].string ?? "")"

      
      return rateCardDetails
  }
    
    
 }
