//
//  UserMyProfileViewController.swift
//  Medbulance
//
//  Created by MacMini  on 06/03/21.
//

import UIKit

class UserMyProfileViewController: BaseViewControllerClass {
    
    static var viewControllerId = "UserMyProfileViewController"
    static var storyBoard = StoryboardConstant.user
    
    
    
    var sideDrawerMenu = SideBarView()
    @IBOutlet weak var sideBarNavigationView: SideMenuNavigationBar!
    
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var txtFieldName: UITextField!
    @IBOutlet weak var view_Edit: UIView!
    @IBOutlet weak var txtFieldEmail: UITextField!
    @IBOutlet weak var txtFieldNumber: UITextField!
    
    var isEditTapped = false
    
    @IBOutlet weak var view_save: UIView!
    @IBOutlet weak var img_pencilcircle: UIImageView!
    @IBOutlet weak var btn_edit: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFieldName.text = UserDetails.sharedInstance.Name
        // txtFieldEmail.text = UserDetails.sharedInstance.Email
        txtFieldNumber.text = UserDetails.sharedInstance.Phone
        callGetProfileDataApi()
        
        appDelegate.window = UIWindow(frame: UIScreen.main.bounds)
        sideDrawerMenu = SideBarView(frame: appDelegate.window!.frame)
        sideDrawerMenu.delegateUser = self
        sideDrawerMenu.logoutDelegate = self
        sideDrawerMenu.isUser = true
        setUpSideMenuNavigation()
        
        self.view_Edit.isHidden = false
        self.view_save.isHidden = true
        txtFieldName.isEnabled = false
        txtFieldEmail.isEnabled = false
        
        
    }
    
    
    @IBAction func action_image(_ sender: Any) {
    }
    
    @IBAction func action_Edit(_ sender: Any) {
        
        isEditTapped = true
        self.view_Edit.isHidden = true
        self.view_save.isHidden = false
        txtFieldName.isEnabled = true
        txtFieldEmail.isEnabled = true
    
    }
    
    func setUpSideMenuNavigation(){
        sideBarNavigationView.lblTitle.text = "My Profile"
        sideBarNavigationView.delegate = self
    }
    
    func showNavigationDrawer() {
        if(sideDrawerMenu != nil && !sideDrawerMenu.isHidden)
        {
            sideDrawerMenu.removeFromSuperview()
        }
        
        sideDrawerMenu.isHidden = false
        UIView.animateKeyframes(withDuration: 0.25, delay: 0, options: [], animations: {
            self.sideDrawerMenu.tableContainerView.center.x += self.view.bounds.width
            
        }, completion: nil)
        sideDrawerMenu.delegateUser = self
        self.view.addSubview(sideDrawerMenu)
        //sideDrawerMenu.tableContainerView.layer.removeAllAnimations()
    }
    
    @IBAction func btnSaveAction(_ sender: Any) {
        
        isEditTapped = false
        view_Edit.isHidden = false
        view_save.isHidden = true
       
        
        let params = ["name":"\(txtFieldName.text!)" , "email":"\(txtFieldEmail.text!)"]
        callUpdateProfile(params:params)
        
    }
    
}
extension UIView {
    func addBottomShadow() {
        layer.masksToBounds = false
        layer.shadowRadius = 2
        layer.shadowOpacity = 0.6
        layer.shadowColor = UIColor.gray.cgColor
        layer.shadowOffset = CGSize(width: 0 , height: 2)
        layer.shadowPath = UIBezierPath(rect: CGRect(x: 0,
                                                     y: bounds.maxY - layer.shadowRadius,
                                                     width: bounds.width,
                                                     height: layer.shadowRadius)).cgPath
    }
}

extension UserMyProfileViewController:SideMenuNavigationBarDelegate,SideBarViewUserDelegate,SideBarViewLogoutDelegate{
    func logoutTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "WelcomeNavController")
        let vc = WelcomeViewController.instantiateFromStoryBoard()
        self.push(vc)
    }
    
    
    func profileTapped(viewController: String) {
        let controller = UserMyProfileViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func bookYourRideTapped(viewController: String) {
        let controller = HomeViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func yourRideTapped(viewController: String) {
        let controller = UserRidesViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func rateCardTapped(viewController: String) {
        let controller = UserRateCardViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func supportTapped(viewController: String) {
        let controller = UsersupportViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func aboutTapped(viewController: String) {
        let controller = UserAboutViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func paymentTapped(viewController: String) {
        let controller = UserPaymentViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func menuBtnTapped() {
        showNavigationDrawer()
    }
    
}

extension UserMyProfileViewController{
    
    func callGetProfileDataApi(){
        
        /*
         if !AppHelper.isInterNetConnectionAvailable(){
         showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
         return
         }
         */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performGETRequest(withURL: kGetUserProfile + UserDetails.sharedInstance.Id) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    
                    if let Values = result?["data"]?.dictionary{
                        
                        if let data = Values["userRegister"]?.dictionary{
                            
                            self.txtFieldName.text! = data["name"]?.stringValue ?? ""
                            //    self.txtFieldNumber.text! = data["phoneNo"]?.stringValue ?? ""
                            self.txtFieldEmail.text! = data["email"]?.stringValue ?? ""
                            
                            
                            UserDetails.sharedInstance.Name = self.txtFieldName.text!
                            //   UserDetails.sharedInstance.Phone = self.txtFieldNumber.text!
                            
                            AppHelper.saveUserDetails()
                            // self.showAlertWithMessage(ConstantStrings.ALERT, "Your OTP is \(otp!)")
                        }
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                        // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
    func callUpdateProfile(params:[String:String]){
        
        /*
         if !AppHelper.isInterNetConnectionAvailable(){
         showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
         return
         }
         */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPUTRequest(withURL: kUpdateUserProfile + UserDetails.sharedInstance.Id, andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    
                    self.txtFieldName.isEnabled = false
                    self.txtFieldEmail.isEnabled = false
                    if let data = result?["data"]?.dictionary{
                        
                        
                        
                        // UserDetails.sharedInstance. = data["email"]?.stringValue ?? ""
                        UserDetails.sharedInstance.Name = data["name"]?.stringValue ?? ""
                        self.sideDrawerMenu.itemList.reloadData()
                        
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                        // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
    
    
}

