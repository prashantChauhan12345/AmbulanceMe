//
//  UserDebitcardCollectionViewCell.swift
//  Medbulance
//
//  Created by MacMini  on 12/03/21.
//

import UIKit

class UserDebitcardCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var containerView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
