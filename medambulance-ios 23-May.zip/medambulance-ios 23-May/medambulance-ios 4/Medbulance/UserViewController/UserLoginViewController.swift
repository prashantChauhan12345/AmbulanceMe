//
//  UserLoginViewController.swift
//  Medbulance
//
//  Created by MacMini  on 04/03/21.
//

import UIKit
import CountryPickerView


class UserLoginViewController: BaseViewControllerClass,UITextFieldDelegate {
    
    static var viewControllerId = "UserLoginViewController"
    static var storyBoard = StoryboardConstant.user
    
    @IBOutlet weak var txt_mobilenumber: UITextField!
    @IBOutlet weak var btn_rememberMe: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setInitials()
    }
    
    
    func setInitials(){
        txt_mobilenumber.delegate = self
    }
    
    @IBAction func action_login(_ sender: Any) {
        
        
        if checkValidation(){
            let param = ["phone":txt_mobilenumber.text!,"email":"","name":""]
            callUserLoginApi(param: param)
        }
       
   //     let controller = GetLocationViewController.instantiateFromStoryBoard()
      //  self.push(controller)
    }
    
    func checkValidation() -> Bool{
        if self.txt_mobilenumber.text!.isEmpty {
            
            self.txt_mobilenumber.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.MOBILE_NO_FIELD_IS_REQUIRED)
            return false
        }
        
        if (self.txt_mobilenumber.text?.isValid(regex: .phone))!{
            
        }else{
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PLEASE_ENTER_VALID_MOBILE)
            return false
        }
        
        return true
    }
    
    @IBAction func action_rememberMe(_ sender: Any) {
        if btn_rememberMe.image(for: .normal) == UIImage(named: "unclicked"){
            btn_rememberMe.setImage(UIImage(named: "clicked"), for: .normal)
        }else{
            btn_rememberMe.setImage(UIImage(named: "unclicked"), for: .normal)
        }
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txt_mobilenumber {
            var maxLength = 10
            let newLength: Int = textField.text!.count - range.length
            let numberOnly = NSCharacterSet.decimalDigits.inverted
            let strValid = string.rangeOfCharacter(from: numberOnly) == nil
            return (strValid && (newLength < maxLength))
        }else{
            return true
        }
    }
    
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension UserLoginViewController{
    
    func callUserLoginApi(param:[String:Any]){
        
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPOSTRequest(withURL: URLBase.baseURL2 + appEndPoints.userRegister  , andParameters: param){(result, error) in
            
            if result != nil {
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                
                if statusCode == 200{
                    
                    print(result!)
                    
                    if let data = result!["data"]?.dictionary{
                        let otp = data["OTP"]?.stringValue
                        UserDetails.sharedInstance.Id = data["id"]!.stringValue
                        let controller = UserVerifyOTPViewController.instantiateFromStoryBoard()
                        controller.number = self.txt_mobilenumber.text!
                        UserDetails.sharedInstance.Phone = self.txt_mobilenumber.text!
                        AppHelper.saveUserDetails()
                        self.push(controller)
                        self.showAlertWithMessage("ALERT",  "Your otp is \(otp!)")
                    }
                   
                }else{
                    
                    let message = result!["message"]?.stringValue
                    self.showAlertWithMessage("ALERT",  message!)
                    
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
            
            
        }
        
    }
    
}


