//
//  AmbulanceListViewController.swift
//  Medbulance
//
//  Created by Apple on 20/03/21.
//

import UIKit
import SwiftyJSON

protocol AmbulanceListViewControllerDelegate{
    func hospitalSelect(lat:String,long:String,address:String)
}
class AmbulanceListViewController: BaseViewControllerClass {
    
    @IBOutlet weak var navigationBar: NavigationBarView!
    var ambulanceList = [HospitalModel]()
    
    
    
    var delegate:AmbulanceListViewControllerDelegate?
    
    static var viewControllerId = "AmbulanceListViewController"
    static var storyBoard = StoryboardConstant.user

    @IBOutlet weak var itemList: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        itemList.register(UINib(nibName: "AmbulanceListTableViewCell", bundle: nil), forCellReuseIdentifier: "AmbulanceListTableViewCell")
        itemList.delegate = self
        itemList.dataSource = self
        let param = ["":""]
        
        callHospitalList(params: param)
        setUpNavigation()
    }
    
    func setUpNavigation(){
       // navigationBar.delegate = self
        navigationBar.lblTitle.text = "Hospital List"
    }
    

    
}
extension AmbulanceListViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ambulanceList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = itemList.dequeueReusableCell(withIdentifier: "AmbulanceListTableViewCell") as? AmbulanceListTableViewCell
        cell!.lblHospitalName.text = ambulanceList[indexPath.row].hospitalName
        cell!.lblLocation.text = ambulanceList[indexPath.row].address
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let element = ambulanceList[indexPath.row]
        
        self.delegate?.hospitalSelect(lat: element.latitude, long: element.longitude, address: element.hospitalName)
        self.dismiss(animated: true, completion: nil)
    }
    
}
extension AmbulanceListViewController{
    
    func callHospitalList(params:[String:String]){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPOSTRequest(withURL: kAmbulanceListURL, andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["status"]?.string
                if statusCode == "true"
                {
                
                    if let data = result?["result"]?.array{
                        
                        self.ambulanceList = HospitalModel.getAllHospitalListArray(hospitalArray:data)
                        
                        self.itemList.reloadData()
                        print(data)
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                   
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
             //   self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}
