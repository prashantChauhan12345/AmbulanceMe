//
//  UserMyProfileTableViewCell.swift
//  Medbulance
//
//  Created by MacMini  on 06/03/21.
//

import UIKit

class UserMyProfileTableViewCell: UITableViewCell {

    @IBOutlet weak var lbl_title: UILabel!
    @IBOutlet weak var lbl_value: UILabel!
    @IBOutlet weak var lbl_line: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
