//
//  Colors.swift
//  Medbulance
//
//  Created by Apple on 23/02/21.
//

import UIKit

class Colors: NSObject {
    
    static let backgroundBG = UIColor(red: 217/255, green: 38/255, blue: 41/255, alpha: 1)
    static let themeColor = UIColor(red: 252/255, green: 49/255, blue: 52/255, alpha: 1)

}
