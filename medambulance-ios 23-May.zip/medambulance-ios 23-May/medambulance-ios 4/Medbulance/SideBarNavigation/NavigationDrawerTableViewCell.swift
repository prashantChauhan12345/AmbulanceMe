//
//  NavigationDrawerTableViewCell.swift
//  driverapp
//
//  Created by MAC on 11/26/19.
//  Copyright © 2019 HyperCommute. All rights reserved.
//

import UIKit

class NavigationDrawerTableViewCell: UITableViewCell {

   
    @IBOutlet weak var titleImage: UIImageView!
    
    @IBOutlet weak var titleLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
