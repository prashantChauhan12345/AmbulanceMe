//
//  DocumentSubmittedViewController.swift
//  Medbulance
//
//  Created by Apple on 03/03/21.
//

import UIKit

class DocumentSubmittedViewController: BaseViewControllerClass {
    
    static var viewControllerId = "DocumentSubmittedViewController"
    static var storyBoard = StoryboardConstant.driver

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.endEditing(true)
     
    }
    
    @IBAction func btnOKAction(_ sender: Any) {
        
        /*
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "LoginSignUpNavController")
        redirectToMainNavRVC(currentVC: controller)
       */
        self.view.endEditing(true)
        let controller = DriverHomeViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    

}
