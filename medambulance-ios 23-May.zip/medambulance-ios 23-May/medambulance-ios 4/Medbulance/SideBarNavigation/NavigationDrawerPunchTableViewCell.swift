//
//  NavigationDrawerPunchTableViewCell.swift
//  HITACHI
//
//  Created by MAC on 12/27/19.
//  Copyright © 2019 MAC. All rights reserved.
//

import UIKit
import CoreLocation
class NavigationDrawerPunchTableViewCell: UITableViewCell {
    
    var isPunchedIn = false
    let locationManger = CLLocationManager()
    @IBOutlet weak var punchInLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var switchOutlet: UISwitch!
   
    var isOkTapped = false
    
    @IBOutlet weak var notPunchedInLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        notPunchedInLbl.isHidden = false
        dateLbl.isHidden = true
        punchInLbl.isHidden = true
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    @IBAction func switchAction(_ sender: UISwitch) {
        let dateFormatter = DateFormatter()
        let swh : UISwitch = sender as! UISwitch
        
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        if locationManger.location?.coordinate.latitude == nil && locationManger.location?.coordinate.longitude == nil{
            //self.presentLocationSettings()
            
            return
        }
        /*
         if !isOkTapped{
         
         if swh.isOn == false{
         /*
         if AppHelper.convertDateStringToFormattedDateString(date: EmpDetails.sharedInstance.punchin_date) == AppHelper.convertDateStringToFormattedDateString(date: dateFormatter.string(from: Date())){
         print("This")
         }else{  */
         notPunchedInLbl.isHidden = false
         dateLbl.isHidden = true
         punchInLbl.isHidden = true
         showlogoutPopup()
         //   }
         
         
         }else{
         
         if AppHelper.convertDateStringToFormattedDateString(date: EmpDetails.sharedInstance.punchin_date) == AppHelper.convertDateStringToFormattedDateString(date: dateFormatter.string(from: Date())){
         // swh.isOn = false
         // sender.setOn(false, animated: true)
         showPopup()
         return
         }else{
         let formatter = DateFormatter()
         // initially set the format based on your datepicker date / server String
         formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
         let myString = formatter.string(from: Date()) // string purpose I add here
         formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
         // convert your string to date
         let yourDate = formatter.date(from: myString)
         //then again set the date format whhich type of output you need
         formatter.dateFormat = "dd MMM yyyy"
         // again convert your date to string
         let myStringafd = formatter.string(from: yourDate!)
         dateLbl.text = myStringafd
         formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
         let showDate = formatter.date(from: myString)
         formatter.dateFormat = "h:mm a"
         let myStringShow = formatter.string(from: showDate!)
         punchInLbl.isHidden = false
         notPunchedInLbl.isHidden = true
         dateLbl.isHidden = false
         punchInLbl.text = "Punched-in \(myStringShow)"
         let params = ["EMPID":EmpDetails.sharedInstance.empID,"punchin_status":"yes","punchin_lat":"\(locationManger.location!.coordinate.latitude)","punchin_long":"\(locationManger.location!.coordinate.longitude)"]
         callPunchInApi(params: params)
         }
         
         
         }
         //  isOkTapped = true
         }else{
         isOkTapped = false
         }
         */
        
    }
    
    func doPunchIn(){
        if switchOutlet.isOn == false{
            /*
             if AppHelper.convertDateStringToFormattedDateString(date: EmpDetails.sharedInstance.punchin_date) == AppHelper.convertDateStringToFormattedDateString(date: dateFormatter.string(from: Date())){
             print("This")
             }else{  */
            notPunchedInLbl.isHidden = false
            dateLbl.isHidden = true
            punchInLbl.isHidden = true
            //   }
            
            
        }else{
            let formatter = DateFormatter()
            // initially set the format based on your datepicker date / server String
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let myString = formatter.string(from: Date()) // string purpose I add here
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            // convert your string to date
            let yourDate = formatter.date(from: myString)
            //then again set the date format whhich type of output you need
            formatter.dateFormat = "dd MMM yyyy"
            // again convert your date to string
            let myStringafd = formatter.string(from: yourDate!)
            dateLbl.text = myStringafd
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let showDate = formatter.date(from: myString)
            formatter.dateFormat = "h:mm a"
            let myStringShow = formatter.string(from: showDate!)
            punchInLbl.isHidden = false
            notPunchedInLbl.isHidden = true
            dateLbl.isHidden = false
            punchInLbl.text = "Punched-in \(myStringShow)"
            
        }
    }
    
    func presentLocationSettings(){
        let alertController = UIAlertController(title: "Hitachi", message: "You need to allow the Location Service", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Cancel", style: .default))
        alertController.addAction(UIAlertAction(title: "Settings", style: .cancel){ _ in
            if let url = URL(string: UIApplication.openSettingsURLString){
                UIApplication.shared.open(url, options: [:], completionHandler:{
                    _ in
                })
            }
            
        })
    //    APPDELEGATE.window?.rootViewController?.present(alertController, animated: true, completion: nil)
        
    }
   
    func okTapped() {
        switchOutlet.isOn = false
        isOkTapped = true
    }
    func okBtnTapAction() {
     
        let formatter = DateFormatter()
        // initially set the format based on your datepicker date / server String
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let myString = formatter.string(from: Date()) // string purpose I add here
    }
    
    func cancelBtnTapAction() {
        switchOutlet.isOn =  true
        punchInLbl.isHidden = false
        notPunchedInLbl.isHidden = true
        dateLbl.isHidden = false
    }
    
    
    
}
