//
//  WelcomeViewController.swift
//  Medbulance
//
//  Created by Apple on 23/02/21.
//

import UIKit

class WelcomeViewController: BaseViewControllerClass {
    
    static var viewControllerId = "WelcomeViewController"
    static var storyBoard = StoryboardConstant.main
    
    @IBOutlet var containerView: [UIView]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setInitials()

    }
    
    func setInitials(){
        self.navigationController?.isNavigationBarHidden = true
        for subView in containerView{
            subView.layer.borderWidth = 1
            subView.layer.borderColor = UIColor.darkGray.cgColor
        }
    }
    
    @IBAction func btnUserAction(_ sender: Any) {
        
        
        if UserDetails.sharedInstance.Id == "" {
            let controller = UserLoginViewController.instantiateFromStoryBoard()
            self.push(controller)
        }else {
            let controller = HomeViewController.instantiateFromStoryBoard()
            self.push(controller)
        }
      
    }
    
    @IBAction func btnDriverAction(_ sender: Any) {
        
        
        if DriverDetails.sharedInstance.Id == "" {
            let controller = LoginSigupViewController.instantiateFromStoryBoard()
            self.push(controller)
        }else {
            let controller = DriverHomeViewController.instantiateFromStoryBoard()
            self.push(controller)
        }
    }
}
