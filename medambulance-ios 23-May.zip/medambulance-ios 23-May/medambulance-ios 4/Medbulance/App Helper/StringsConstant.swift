//
//  StringsConstant.swift
//  Deals
//
//  Created by Vinay Piplani on 22/10/19.
//  Copyright © 2019 Piplani. All rights reserved.
//

import Foundation
class StringsConstant  {
    var passwordAndConfirmPasswordNotMatch = "Password and confirm password doesn't match"
    var error = "Error"
    var takePhoto = "Take Photo"
    var cameraRoll = "Camera Roll"
    var photoLibrary = "Photo Library"
    var cancel = "cancel"
    var success = "Success"
    var somethingGoodHappened = "something Good Happened"
    var retry = "retry"
    var warning = "warning"
    var somethingWentWrongTryAfterSometimes = "Something Went Wrong Try After Sometimes"
    var infomation = "infomation"
    
    var pleaseEnterEmail = "Please Enter Email"
    var pleaseEnterAValidEmail = "Please Enter A Valid Email"
    var pleaseEnterYourFullName = "please Enter Your Full Name"
    var pleaseEnterPassword = "Please Enter Password"
    var pleaseEnterValidPassword = "Please Enter A Valid Password"
    var more = "more"
    var less = "less"
    var pleaseCheckYourEmail = "Please Check your email id"
    var forgotPasswordLinkSendSuccessfully = "Forgot Password Link Send Successfully"

}
