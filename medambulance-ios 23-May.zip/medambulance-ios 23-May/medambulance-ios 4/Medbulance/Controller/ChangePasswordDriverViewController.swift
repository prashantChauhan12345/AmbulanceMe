//
//  ChangePasswordDriverViewController.swift
//  Medbulance
//
//  Created by Apple on 08/03/21.
//

import UIKit

class ChangePasswordDriverViewController: BaseViewControllerClass {
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    @IBOutlet weak var txtFieldConfirmPassword: UITextField!
    static var viewControllerId = "ChangePasswordDriverViewController"
    static var storyBoard = StoryboardConstant.driver
    
    
    var phone = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    //    Check validation
    func checkValidation() -> Bool {
        
        self.view.endEditing(true)
      
    
        
        if self.txtFieldPassword.text!.isEmpty {
            
            self.txtFieldPassword.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PASSWORD_FIELD_IS_REQUIRED)
            return false
        }
        
        if self.txtFieldPassword.text!.count < 0 {
            
            self.txtFieldPassword.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PASSWORD_FIELD_MIN_SIX)
            return false
        }
        
        if self.txtFieldConfirmPassword.text!.isEmpty {
            
            self.txtFieldConfirmPassword.becomeFirstResponder()
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.CONFIRM_PASSWORD_FIELD_IS_REQUIRED)
            return false
        }
        
        if self.txtFieldPassword.text! != txtFieldConfirmPassword.text!{
            self.showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.PASSWORD_AND_CONFIRM_PASSWORD_DIDNOT_MATCH)
            return false
        }
        
        return true
    }
    
    @IBAction func btnChangePasswordAction(_ sender: Any) {
        
        if checkValidation(){
            let param = [
                "password":txtFieldPassword.text!]
            callChangePasswordApi(params: param)
        }
    }
    
    @IBAction func showPasswordAction(_ sender: Any) {
        txtFieldPassword.isSecureTextEntry.toggle()
    }
    

}
extension ChangePasswordDriverViewController{
    
    func callChangePasswordApi(params:[String:String]){
        
        /*
        if !AppHelper.isInterNetConnectionAvailable(){
            showAlertWithMessage(ConstantStrings.ALERT, ConstantStrings.pleaseCheckYourInternetConnection)
            return
        }
        */
        ERProgressHud.sharedInstance.showBlurView(withTitle: "Loading...")
        WebServiceHandler.performPUTRequest(withURL: kChangePasswordURL + "\(phone)", andParameters: params) {(result,error) in
            if result != nil{
                print(result!)
                
                let statusCode = result!["statusCode"]?.int
                if statusCode == 200
                {
                    
                    let message = result!["message"]?.string
                    let alertController = UIAlertController.init(title: ConstantStrings.ALERT, message: message, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction.init(title: "OK", style: .default){ action in
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let controller = storyboard.instantiateViewController(withIdentifier: "LoginSignUpNavController")
                        self.redirectToMainNavRVC(currentVC: controller)
                    }
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                   
                    
                    
                  
                    
                    if let data = result?["data"]?.dictionary{
                        
                   
                       
                    }
                }
                else{
                    if let message = result!["message"]?.string{
                       // AppHelper.showAlertView(message: errorMsg)
                        self.showAlertWithMessage(ConstantStrings.ALERT, message)
                    }
                }
                ERProgressHud.sharedInstance.hide()
            }else{
                self.showAlertWithMessage("ALERT",  "Something Went Wrong")
                ERProgressHud.sharedInstance.hide()
            }
        }
    }
    
}

