//
//  UserAboutViewController.swift
//  Medbulance
//
//  Created by MacMini  on 09/03/21.
//

import UIKit

class UserAboutViewController: BaseViewControllerClass {
    
    var sideDrawerMenu = SideBarView()
    @IBOutlet weak var sideBarNavigationView: SideMenuNavigationBar!
    
    static var viewControllerId = "UserAboutViewController"
    static var storyBoard = StoryboardConstant.user

    override func viewDidLoad() {
        super.viewDidLoad()
        
        appDelegate.window = UIWindow(frame: UIScreen.main.bounds)
        sideDrawerMenu = SideBarView(frame: appDelegate.window!.frame)
        sideDrawerMenu.delegateUser = self
        sideDrawerMenu.logoutDelegate = self
        sideDrawerMenu.isUser = true
        setUpSideMenuNavigation()

        // Do any additional setup after loading the view.
    }
    
    
    func setUpSideMenuNavigation(){
        sideBarNavigationView.lblTitle.text = "About"
        sideBarNavigationView.delegate = self
    }
    
    func showNavigationDrawer() {
        if(sideDrawerMenu != nil && !sideDrawerMenu.isHidden)
        {
            sideDrawerMenu.removeFromSuperview()
        }
      
        sideDrawerMenu.isHidden = false
        UIView.animateKeyframes(withDuration: 0.25, delay: 0, options: [], animations: {
            self.sideDrawerMenu.tableContainerView.center.x += self.view.bounds.width
            
        }, completion: nil)
        sideDrawerMenu.delegateUser = self
        self.view.addSubview(sideDrawerMenu)
        //sideDrawerMenu.tableContainerView.layer.removeAllAnimations()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UserAboutViewController:SideMenuNavigationBarDelegate,SideBarViewUserDelegate,SideBarViewLogoutDelegate{
    func logoutTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "WelcomeNavController")
        let vc = WelcomeViewController.instantiateFromStoryBoard()
        self.push(vc)
    }
    
    
    func profileTapped(viewController: String) {
        let controller = UserMyProfileViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func bookYourRideTapped(viewController: String) {
        let controller = HomeViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func yourRideTapped(viewController: String) {
        let controller = UserRidesViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func rateCardTapped(viewController: String) {
        let controller = UserRateCardViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func supportTapped(viewController: String) {
        let controller = UsersupportViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func aboutTapped(viewController: String) {
        let controller = UserAboutViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func paymentTapped(viewController: String) {
        let controller = UserPaymentViewController.instantiateFromStoryBoard()
        self.push(controller)
    }
    
    func menuBtnTapped() {
        showNavigationDrawer()
    }
    
}
